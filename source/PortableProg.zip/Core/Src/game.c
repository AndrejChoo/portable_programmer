/*
 * game.c
 *
 *  Created on: Jan 27, 2025
 *      Author: andre
 */

#include "game.h"

extern uint8_t menu, punkt, punkt1;
//Buttons
extern volatile uint8_t up, down, left, right, set;

//Tetris variables
uint8_t start = 0;
uint16_t main_delay = 800;
uint16_t score = 0;
uint8_t level = 1;
uint8_t speed = 1;
uint8_t level_count;
uint8_t x_pos = 8, y_pos = 0; //Положение фигуры в блоках 8х8 пикселей
uint8_t fig, next_fig;
char str[5];

uint16_t field[22] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const int8_t figura [19][9] = {
		{0,-1,0,-2,0,-3,1},  //0
		{-1,0,1,0,2,0,0},    //1
		{-1,0,0,-1,1,-1,3},  //2
		{0,-1,-1,-1,-1,-2,2},//3
		{-1,0,1,0,0,-1,5},   //4
		{0,-1,1,-1,0,-2,6},  //5
		{0,-1,-1,-1,1,-1,7}, //6
		{0,-1,-1,-1,0,-2,4}, //7
		{1,0,0,-1,-1,-1,9},  //8
		{0,-1,1,-1,1,-2,8},  //9
		{-1,0,-1,-1,0,-1,10},//10
		{1,0,0,-1,0,-2,12},  //11
		{1,0,2,0,2,-1,13},   //12
		{0,-1,0,-2,-1,-2,14},//13
		{0,-1,1,-1,2,-1,11}, //14
		{1,0,1,-1,1,-2,16},  //15
		{1,0,2,0,0,-1,17},   //16
		{0,-1,0,-2,1,-2,18}, //17
		{0,-1,-1,-1,-2,-1,15}//18
};


void game_menu(void)
{
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(60, 1, "Games", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "Tetris", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	punkt = 0;
	punkt1 = 0;

	while(menu == 255)
	{
		cursor_move(2);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Tetris
				{
					menu = 254;
					break;
				}
				case 1: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 0;
					break;
				}
			}
			set = 0;
		}
	}
}

//
void tetris(void)
{
	TFT_drawString(55,40,"Tetris",COLOR_BLACK,COLOR_WHITE,4);
	HAL_Delay(1500);

	game_begin();

	while(menu == 254)//Основной цикл игры
	{
		next_fig = rand()%18; //Генерируем следующую фигуру
		draw_fig(next_fig, 140, 90, 1); //Отрисовываем следующую фигуру сбоку
		for(int i=0;i<22;i++)
		{
			draw_fig(fig, x_pos*8, (y_pos)*8, 1);
			delay(main_delay-level*100);
	        if(i==21){save_pos(); break;}
	        if(check_pos(fig, x_pos,y_pos+1)){save_pos(); break;}
	        draw_fig(fig, x_pos*8, (y_pos*8), 0);
	        y_pos++;
		}
		do{check_strings();}
		while(check_full());

		if(field[0]){game_over();} //Если первая строка занята - то гамон

		draw_fig(next_fig, 140, 90, 0); //Стираем изображение следующей фигуры
		fig = next_fig; //Назначаем следующую фигуру текущей
		x_pos = 8; //Обнуляем координаты
		y_pos = 0;
	}
}

	//Отрисовываем игровое поле
	void game_begin(void)
	{
		fig = rand()%18;
		TFT_fillScreen(COLOR_WHITE);
		drawFastVLine(128, 0, 176, COLOR_BLACK);
		drawFastHLine(0, 176, 128, COLOR_BLACK);
		TFT_drawString(135,2,"Level",COLOR_BLACK,COLOR_WHITE,1);
		sprintf(str,"%d",level);
		TFT_drawString(135,10,str,COLOR_BLACK,COLOR_WHITE,1);
		TFT_drawString(135,25,"Score",COLOR_BLACK,COLOR_WHITE,1);
		sprintf(str,"%d",score);
		TFT_drawString(135,33,str,COLOR_BLACK,COLOR_WHITE,1);
		TFT_drawString(135,50,"Next",COLOR_BLACK,COLOR_WHITE,1);
		//start = 0;
	}


	void game_over(void)
	{
		for(int i=21;i>=0;i--)
		{
			field[i]=0;
		}

		TFT_fillScreen(COLOR_BLACK);
		TFT_drawString(40,40,"Game Over",COLOR_RED,COLOR_BLACK,2);
		TFT_drawString(2,85,"Press set button",COLOR_BLUE,COLOR_BLACK,1);
		sprintf(str,"Total score %d",score);
		TFT_drawString(60,100,str,COLOR_WHITE,COLOR_BLACK,1);
		score = 0;
		level = 1;
		speed = 1;
		level_count = 0;
		while(!start);
		start = 0;
		menu = 255;
	}


	//Отрисовка одного блока
	void draw_block(uint16_t x, uint16_t y, bool visible)
	{
		if(visible) TFT_fillRectangle(x, y, 8, 8, COLOR_BLACK);
		else TFT_fillRectangle(x, y, 8, 8, COLOR_WHITE);
	}

	//отрисовка фигуры
	void draw_fig(uint8_t fig, uint16_t x, uint16_t y, bool visible)
	{
		draw_block(x,y,visible);
		draw_block(x+figura[fig][0]*8,y+figura[fig][1]*8,visible);
		draw_block(x+figura[fig][2]*8,y+figura[fig][3]*8,visible);
		draw_block(x+figura[fig][4]*8,y+figura[fig][5]*8,visible);
	}

	void shift_left(void)
	{
	    uint8_t f0 = x_pos;
	    uint8_t f1 = x_pos+figura[fig][0];
	    uint8_t f2 = x_pos+figura[fig][2];
	    uint8_t f3 = x_pos+figura[fig][4];
		if((!check_pos(fig, (x_pos-1),y_pos)) && (f0>0) && (f1>0) && (f2>0) && (f3>0)) {
			draw_fig(fig, x_pos*8, y_pos*8, 0);
			draw_fig(fig, (x_pos-1)*8, y_pos*8, 1);
			x_pos -= 1;
		}
	}

	void shift_right(void)
	{
	    uint8_t f0 = x_pos;
	    uint8_t f1 = x_pos+figura[fig][0];
	    uint8_t f2 = x_pos+figura[fig][2];
	    uint8_t f3 = x_pos+figura[fig][4];
		if((!check_pos(fig, (x_pos-1),y_pos)) && (f0<15) && (f1<15) && (f2<15) && (f3<15)) {
			draw_fig(fig, x_pos*8, y_pos*8, 0);
			draw_fig(fig, (x_pos+1)*8, y_pos*8, 1);
			x_pos += 1;
		}
	}

	void rotate(void)
	{
		uint8_t rot_fig = figura[fig][6];
	    uint8_t f1 = x_pos+figura[rot_fig][0];
	    uint8_t f2 = x_pos+figura[rot_fig][2];
	    uint8_t f3 = x_pos+figura[rot_fig][4];

		if(f1<0 || f2<0 || f3<0) return;
		if(f1>15 || f2>15 || f3>15) return;
	    if(!check_pos(rot_fig, x_pos,y_pos))
		{
			draw_fig(fig, x_pos*8, y_pos*8, 0);
			draw_fig(rot_fig, x_pos*8, y_pos*8, 1);
			fig = rot_fig;
		}
	}

	void delay(uint16_t del)
	{
		for(int i=0; i<8; i++)
		{
			if(down==1){down=0; break;}
			if(left==1){shift_left(); left=0;}
			if(right==1){shift_right(); right=0;}
			if(up==1){rotate(); up=0;}
			if(set){start = 1; set = 0;}
			HAL_Delay(del/8);
		}
	}


	bool check_pos(uint8_t fg, uint8_t x, uint8_t y)
	{
		uint16_t f0 = field[y] & 1<<x;
		uint16_t f1 = field[(y+figura[fg][1])] & 1<<(x+figura[fg][0]);
		uint16_t f2 = field[(y+figura[fg][3])] & 1<<(x+figura[fg][2]);
		uint16_t f3 = field[(y+figura[fg][5])] & 1<<(x+figura[fg][4]);
		if((f0|f1|f2|f3)==0){return 0;}
		else{return 1;}
	}

	void save_pos(void)
	{
		field[y_pos] |= 1<<x_pos;
		field[(y_pos+figura[fig][1])] |= 1<<(x_pos+figura[fig][0]);
		field[(y_pos+figura[fig][3])] |= 1<<(x_pos+figura[fig][2]);
		field[(y_pos+figura[fig][5])] |= 1<<(x_pos+figura[fig][4]);
	}

	//Отрисовывает одну строку по индексу curr_row
	void draw_row(uint8_t curr_row, uint16_t data)
	{
		for(int i = 0; i<16; i++)
		{
			if((data & (1<<i))==(1<<i))
			{
				draw_block(i*8, curr_row*8, 1);
			}
			else{draw_block(i*8, curr_row*8, 0);}
		}
	}


	void check_strings(void)
	{
		for(int i=21; i>=0; i--)
		{
			if(field[i]==0xFFFF)//Если строка полная
			{
				score += 16;
				level_count++;
				if(level_count==8)
				{
					level++;
					level_count=0;
					sprintf(str,"%d",level);
					TFT_drawString(135,10,str,COLOR_BLACK,COLOR_WHITE,1);
				}

				sprintf(str,"%d",score);
				TFT_drawString(135,33,str,COLOR_BLACK,COLOR_WHITE,1);

				for(int j=i; i>0; j--)
				{
					if(field[j-1]>0){
						draw_row(j, field[j-1]);
						field[j] = field[j-1];}
					else{draw_row(j, 0);
					     field[j] = 0;
					     break;}
				}
			}
			if(field[i]==0)break;
		}
	}

	//Проверяем на наличие заполненных строк
	bool check_full(void)
	{
		for(int i=21;i>=0;i--)
		{
			if(field[i]==0xffff)
			{
				return 1;
			}
		}
		return 0;
	}






