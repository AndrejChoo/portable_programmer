/*
 * game.c
 *
 *  Created on: Jan 27, 2025
 *      Author: andre
 */

#include "game.h"

extern uint8_t menu, punkt, punkt1;
extern uint8_t main_buff[];
extern uint8_t string[];
//Buttons
extern volatile uint8_t up, down, left, right, set;

//Tetris variables
uint8_t start = 0;
uint16_t main_delay = 800;
uint16_t score = 0;
uint8_t level = 1;
uint8_t speed = 1;
uint8_t level_count;
uint8_t x_pos = 8, y_pos = 0; //Положение фигуры в блоках 8х8 пикселей
uint8_t fig, next_fig;
char str[5];

uint16_t field[22] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const int8_t figura [19][9] = {
		{0,-1,0,-2,0,-3,1},  //0
		{-1,0,1,0,2,0,0},    //1
		{-1,0,0,-1,1,-1,3},  //2
		{0,-1,-1,-1,-1,-2,2},//3
		{-1,0,1,0,0,-1,5},   //4
		{0,-1,1,-1,0,-2,6},  //5
		{0,-1,-1,-1,1,-1,7}, //6
		{0,-1,-1,-1,0,-2,4}, //7
		{1,0,0,-1,-1,-1,9},  //8
		{0,-1,1,-1,1,-2,8},  //9
		{-1,0,-1,-1,0,-1,10},//10
		{1,0,0,-1,0,-2,12},  //11
		{1,0,2,0,2,-1,13},   //12
		{0,-1,0,-2,-1,-2,14},//13
		{0,-1,1,-1,2,-1,11}, //14
		{1,0,1,-1,1,-2,16},  //15
		{1,0,2,0,0,-1,17},   //16
		{0,-1,0,-2,1,-2,18}, //17
		{0,-1,-1,-1,-2,-1,15}//18
};


void game_menu(void)
{
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(60, 1, "Games", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "Tetris", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Snake", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "NeedForSpeed", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	punkt = 0;
	punkt1 = 0;

	while(menu == 255)
	{
		cursor_move(4);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Tetris
				{
					menu = 254;
					break;
				}
				case 1: //Snake
				{
					menu = 253;
					break;
				}
				case 2: //Gonki
				{
					menu = 252;
					break;
				}
				case 3: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 0;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

//
void tetris(void)
{
	TFT_drawString(55,40,"Tetris",COLOR_BLACK,COLOR_WHITE,4);
	HAL_Delay(1500);

	game_begin();
	score = 0;
	level = 0;

	while(menu == 254)//Основной цикл игры
	{
		next_fig = rand()%18; //Генерируем следующую фигуру
		draw_fig(next_fig, 140, 90, 1); //Отрисовываем следующую фигуру сбоку
		for(int i=0;i<22;i++)
		{
			draw_fig(fig, x_pos*8, (y_pos)*8, 1);
			delay(main_delay-level*100);
	        if(i==21){save_pos(); break;}
	        if(check_pos(fig, x_pos,y_pos+1)){save_pos(); break;}
	        draw_fig(fig, x_pos*8, (y_pos*8), 0);
	        y_pos++;
		}
		do{check_strings();}
		while(check_full());

		if(field[0]){game_over();} //Если первая строка занята - то гамон

		draw_fig(next_fig, 140, 90, 0); //Стираем изображение следующей фигуры
		fig = next_fig; //Назначаем следующую фигуру текущей
		x_pos = 8; //Обнуляем координаты
		y_pos = 0;
	}
}

	//Отрисовываем игровое поле
	void game_begin(void)
	{
		fig = rand()%18;
		TFT_fillScreen(COLOR_WHITE);
		drawFastVLine(128, 0, 176, COLOR_BLACK);
		drawFastHLine(0, 176, 128, COLOR_BLACK);
		TFT_drawString(135,2,"Level",COLOR_BLACK,COLOR_WHITE,1);
		sprintf(str,"%d",level);
		TFT_drawString(135,10,str,COLOR_BLACK,COLOR_WHITE,1);
		TFT_drawString(135,25,"Score",COLOR_BLACK,COLOR_WHITE,1);
		sprintf(str,"%d",score);
		TFT_drawString(135,33,str,COLOR_BLACK,COLOR_WHITE,1);
		TFT_drawString(135,50,"Next",COLOR_BLACK,COLOR_WHITE,1);
		//start = 0;
	}


	void game_over(void)
	{
		for(int i=21;i>=0;i--)
		{
			field[i]=0;
		}

		TFT_fillScreen(COLOR_BLACK);
		TFT_drawString(40,40,"Game Over",COLOR_RED,COLOR_BLACK,2);
		TFT_drawString(2,85,"Press set button",COLOR_BLUE,COLOR_BLACK,1);
		sprintf(str,"Total score %d",score);
		TFT_drawString(60,100,str,COLOR_WHITE,COLOR_BLACK,1);
		score = 0;
		level = 1;
		speed = 1;
		level_count = 0;
		HAL_Delay(1500);
		menu = 255;
	}


	//Отрисовка одного блока
	void draw_block(uint16_t x, uint16_t y, bool visible)
	{
		if(visible) TFT_fillRectangle(x, y, 8, 8, COLOR_BLACK);
		else TFT_fillRectangle(x, y, 8, 8, COLOR_WHITE);
	}

	//отрисовка фигуры
	void draw_fig(uint8_t fig, uint16_t x, uint16_t y, bool visible)
	{
		draw_block(x,y,visible);
		draw_block(x+figura[fig][0]*8,y+figura[fig][1]*8,visible);
		draw_block(x+figura[fig][2]*8,y+figura[fig][3]*8,visible);
		draw_block(x+figura[fig][4]*8,y+figura[fig][5]*8,visible);
	}

	void shift_left(void)
	{
	    uint8_t f0 = x_pos;
	    uint8_t f1 = x_pos+figura[fig][0];
	    uint8_t f2 = x_pos+figura[fig][2];
	    uint8_t f3 = x_pos+figura[fig][4];
		if((!check_pos(fig, (x_pos-1),y_pos)) && (f0>0) && (f1>0) && (f2>0) && (f3>0)) {
			draw_fig(fig, x_pos*8, y_pos*8, 0);
			draw_fig(fig, (x_pos-1)*8, y_pos*8, 1);
			x_pos -= 1;
		}
	}

	void shift_right(void)
	{
	    uint8_t f0 = x_pos;
	    uint8_t f1 = x_pos+figura[fig][0];
	    uint8_t f2 = x_pos+figura[fig][2];
	    uint8_t f3 = x_pos+figura[fig][4];
		if((!check_pos(fig, (x_pos-1),y_pos)) && (f0<15) && (f1<15) && (f2<15) && (f3<15)) {
			draw_fig(fig, x_pos*8, y_pos*8, 0);
			draw_fig(fig, (x_pos+1)*8, y_pos*8, 1);
			x_pos += 1;
		}
	}

	void rotate(void)
	{
		uint8_t rot_fig = figura[fig][6];
	    uint8_t f1 = x_pos+figura[rot_fig][0];
	    uint8_t f2 = x_pos+figura[rot_fig][2];
	    uint8_t f3 = x_pos+figura[rot_fig][4];

		if(f1<0 || f2<0 || f3<0) return;
		if(f1>15 || f2>15 || f3>15) return;
	    if(!check_pos(rot_fig, x_pos,y_pos))
		{
			draw_fig(fig, x_pos*8, y_pos*8, 0);
			draw_fig(rot_fig, x_pos*8, y_pos*8, 1);
			fig = rot_fig;
		}
	}

	void delay(uint16_t del)
	{
		for(int i=0; i<8; i++)
		{
			if(down==1){down=0; break;}
			if(left==1){shift_left(); left=0;}
			if(right==1){shift_right(); right=0;}
			if(up==1){rotate(); up=0;}
			if(set){start = 1; set = 0;}
			HAL_Delay(del/8);
		}
	}


	bool check_pos(uint8_t fg, uint8_t x, uint8_t y)
	{
		uint16_t f0 = field[y] & 1<<x;
		uint16_t f1 = field[(y+figura[fg][1])] & 1<<(x+figura[fg][0]);
		uint16_t f2 = field[(y+figura[fg][3])] & 1<<(x+figura[fg][2]);
		uint16_t f3 = field[(y+figura[fg][5])] & 1<<(x+figura[fg][4]);
		if((f0|f1|f2|f3)==0){return 0;}
		else{return 1;}
	}

	void save_pos(void)
	{
		field[y_pos] |= 1<<x_pos;
		field[(y_pos+figura[fig][1])] |= 1<<(x_pos+figura[fig][0]);
		field[(y_pos+figura[fig][3])] |= 1<<(x_pos+figura[fig][2]);
		field[(y_pos+figura[fig][5])] |= 1<<(x_pos+figura[fig][4]);
	}

	//Отрисовывает одну строку по индексу curr_row
	void draw_row(uint8_t curr_row, uint16_t data)
	{
		for(int i = 0; i<16; i++)
		{
			if((data & (1<<i))==(1<<i))
			{
				draw_block(i*8, curr_row*8, 1);
			}
			else{draw_block(i*8, curr_row*8, 0);}
		}
	}


	void check_strings(void)
	{
		for(int i=21; i>=0; i--)
		{
			if(field[i]==0xFFFF)//Если строка полная
			{
				score += 16;
				level_count++;
				if(level_count==8)
				{
					level++;
					level_count=0;
					sprintf(str,"%d",level);
					TFT_drawString(135,10,str,COLOR_BLACK,COLOR_WHITE,1);
				}

				sprintf(str,"%d",score);
				TFT_drawString(135,33,str,COLOR_BLACK,COLOR_WHITE,1);

				for(int j=i; i>0; j--)
				{
					if(field[j-1]>0){
						draw_row(j, field[j-1]);
						field[j] = field[j-1];}
					else{draw_row(j, 0);
					     field[j] = 0;
					     break;}
				}
			}
			if(field[i]==0)break;
		}
	}

	//Проверяем на наличие заполненных строк
	bool check_full(void)
	{
		for(int i=21;i>=0;i--)
		{
			if(field[i]==0xffff)
			{
				return 1;
			}
		}
		return 0;
	}

/////////////////////////////////////SNAKE//////////////////////////////////////

#define SNAKE_MAX_X		21
#define SNAKE_MAX_Y		21
//uint8_t main_buff[(SNAKE_MAX_X+1)*(SNAKE_MAX_Y+1)*2];
uint8_t head;
uint16_t s_lenght = 3;
uint8_t direction = 0; //0-Right, 1-Down, 2-Left, 3-Up
uint16_t move_delay, sn_score = 0, sn_level = 0;
uint8_t apple[2], new_head[2];

void snake(void)
{
	TFT_fillScreen(COLOR_WHITE);
	drawFastHLine(0, 177, 176, COLOR_BLACK);

    //Начальные координаты
	move_delay = 500;
    head = 2;
    main_buff[0]=0; //X
    main_buff[1]=0; //Y
    main_buff[2]=1; //X
    main_buff[3]=0; //Y
    main_buff[4]=2; //X
    main_buff[5]=0; //Y
    draw_segment(0, 0, COLOR_GREEN);
    draw_segment(8, 0, COLOR_GREEN);
    draw_segment(16, 0, COLOR_GREEN);
    generate_apple();
	sprintf(string,"Score: %d",sn_score);
	TFT_drawString(60,200,string,COLOR_BLACK,COLOR_WHITE,1);


	while(menu == 253)
	{
		check_buttons();
		HAL_Delay(move_delay);
		check_buttons();


		//Проверка изменения направления
        switch(direction)
        {
            case 0: //Right
            {
            	if(main_buff[head*2] == SNAKE_MAX_X)
            	{
            		snake_gamon();
            		break;
            	}
                new_head[0] = main_buff[head*2] + 1; //X++
                new_head[1] = main_buff[head*2+1];
                break;
            }
            case 1: //Down
            {
            	if(main_buff[head*2+1] == SNAKE_MAX_Y)
            	{
            		snake_gamon();
            		break;
            	}
                new_head[0] = main_buff[head*2]; //X++
                new_head[1] = main_buff[head*2+1] + 1;
                break;
            }
            case 2: //Left
            {
            	if((main_buff[head*2]) == 0)
            	{
            		snake_gamon();
            		break;
            	}
                new_head[0] = main_buff[head*2] - 1; //X++
                new_head[1] = main_buff[head*2+1];
                break;
            }
            case 3: //Up
            {
            	if((main_buff[head*2+1]) == 0)
            	{
            		snake_gamon();
            		break;
            	}
                new_head[0] = main_buff[head*2]; //X++
                new_head[1] = main_buff[head*2+1] - 1;
                break;
            }
        }


        if(new_head[0]==apple[0] && new_head[1]==apple[1])
        {
            head++;
            s_lenght++;
            sn_score++;
            sn_level++;
            move_delay --;
            main_buff[head*2] = new_head[0];
            main_buff[head*2+1] = new_head[1];
            draw_head(COLOR_GREEN);
            generate_apple();
        	sprintf(string,"Score: %d",sn_score);
        	TFT_drawString(60, 200, string, COLOR_BLACK, COLOR_WHITE, 1);
        }
        else
        {
            draw_tail(COLOR_WHITE);
            rewrite_array();
            main_buff[head*2] = new_head[0];
            main_buff[head*2+1] = new_head[1];
            draw_head(COLOR_GREEN);
        }


		if(check_crash())snake_gamon();

	}
}

//Служебные функции
void draw_segment(uint16_t x, uint16_t y, uint16_t color)
{
    TFT_fillCircle(x+4, y+4, 4, color);
}

void generate_apple(void)
{
    uint8_t comp = 0;
    do
    {
    	comp = 0;
        apple[0] = rand() % SNAKE_MAX_X; //X
        apple[1] = rand() % SNAKE_MAX_Y; //Y
        for(uint8_t i = 0; i < s_lenght; i++)
        {
            if(apple[0] == main_buff[i*2] && apple[1] == main_buff[i*2+1]) comp = 1;
        }
    }
    while(comp);

    draw_segment(apple[0]*8, apple[1]*8, COLOR_RED);
}

void draw_head(uint16_t color)
{
    draw_segment(main_buff[head*2]*8, main_buff[head*2+1]*8, color);
}

void draw_tail(uint16_t color)
{
    draw_segment(main_buff[0]*8, main_buff[1]*8, color);
}

void check_buttons(void)
{
	//0-Right, 1-Down, 2-Left, 3-Up
    if(up)
    {
        if(direction != 1) direction = 3;
        up = 0;
    }
    if(down)
    {
        if(direction != 3) direction = 1;
        down = 0;
    }
    if(right)
    {
        if(direction != 2) direction = 0;
        right = 0;
    }
    if(left)
    {
        if(direction != 0) direction = 2;
        left = 0;
    }
}

uint8_t check_crash(void)
{
	uint8_t comp = 0;
    for(uint8_t i = 1; i < (s_lenght-1); i++)
    {
        if(main_buff[head*2] == main_buff[i*2] && main_buff[head*2+1] == main_buff[i*2+1]) comp = 1;
    }
    return comp;
}

void rewrite_array(void)
{
    for (int i = 0; i < s_lenght-1; i++)
    {
    	main_buff[i*2] = main_buff[(i + 1)*2];
    	main_buff[i*2+1] = main_buff[(i + 1)*2+1];
    }
}

void snake_gamon(void)
{
	TFT_drawString(55,180,"GAMON",COLOR_BLACK,COLOR_WHITE,2);
    head = 2;
    sn_score = 0;
    sn_level = 0;
    s_lenght = 3;
    direction = 0;
    main_buff[0]=0; //X
    main_buff[1]=0; //Y
    main_buff[2]=1; //X
    main_buff[3]=0; //Y
    main_buff[4]=2; //X
    main_buff[5]=0; //Y
	HAL_Delay(1500);
	menu = 255;
}



////////////////////////////////Cars/////////////////////////////////////////
#define MAX_WIDTH   128
#define CAR_WIDTH   24
#define MAX_RTURN   (MAX_WIDTH-CAR_WIDTH-1)
#define MAX_HEIGHT  220

uint16_t car_posx, car_posy;
uint8_t wall_posy, door_posx;

void cars(void)
{
	score = 0;
	level = 0;
	move_delay = 80;
	wall_posy = 0;
	car_posx = 32;
	car_posy = (MAX_HEIGHT - 40 - 1);
	TFT_fillScreen(COLOR_WHITE);
    draw_car(car_posx, car_posy);
    drawFastVLine(MAX_WIDTH, 0, MAX_HEIGHT, COLOR_BLACK);
    generate_door();
    draw_wall(0, door_posx, 1);
    TFT_drawString(133,30,"Score:",COLOR_BLACK,COLOR_WHITE,1);
    sprintf(string,"%d",score);
    TFT_drawString(133, 39, string, COLOR_BLACK, COLOR_WHITE, 1);

	while(menu == 252)
	{
        move_car();
        HAL_Delay(move_delay);
        move_car();

        draw_wall(wall_posy, door_posx, 0);

        if(wall_posy <= MAX_HEIGHT-4)
        {
            wall_posy += 4;
            draw_wall(wall_posy, door_posx, 1);
        }
        else
        {
            wall_posy = 0;
            generate_door();
            draw_wall(wall_posy, door_posx, 1);
            score++;
            level++;
            if(level == 5)
            {
            	level = 0;
            	move_delay--;
            }
            TFT_drawString(133,30,"Score:",COLOR_BLACK,COLOR_WHITE,1);
            sprintf(string,"%d",score);
            TFT_drawString(133, 39, string, COLOR_BLACK, COLOR_WHITE, 1);
        }

        if(wall_posy >= car_posy)
        {
            draw_car(car_posx, car_posy);
            if(car_posx != door_posx*8) snake_gamon();
        }
	}
}

void draw_car(uint16_t x, uint16_t y)
{
	TFT_fillRectangle(x, y, 24, 40, COLOR_RED);
	TFT_fillRectangle(x, y+4, 4, 8, COLOR_BLACK); //LS Wheel
	TFT_fillRectangle(x, y+28, 4, 8, COLOR_BLACK); //LI Wheel
	TFT_fillRectangle(x+20, y+4, 4, 8, COLOR_BLACK); //RS Wheel
	TFT_fillRectangle(x+20, y+28, 4, 8, COLOR_BLACK); //RI Wheel
	TFT_fillRectangle(x+6, y+12, 12, 8, COLOR_BLACK); //S Glass
	TFT_fillRectangle(x+6, y+32, 12, 4, COLOR_BLACK); //I Glass
	TFT_fillRectangle(x+6, y+20, 12, 12, COLOR_BLACK); //Ramka
}

void clear_car(uint16_t x, uint16_t y)
{
	TFT_fillRectangle(x, y, 24, 40, COLOR_WHITE);
}

void move_car(void)
{
    if(left)
    {
        if(car_posx >= 8)
        {
            clear_car(car_posx, car_posy);
            car_posx -= 8;
            draw_car(car_posx, car_posy);
        }
        left = 0;
    }
    if(right)
    {
        if(car_posx < MAX_RTURN)
        {
            clear_car(car_posx, car_posy);
            car_posx += 8;
            draw_car(car_posx, car_posy);
        }
        right = 0;
    }
    if(up) up = 0;
    if(down) down = 0;
    if(set) set = 0;
}

void draw_wall(uint16_t y, uint8_t door, uint8_t visible)
{
    if(!visible)
    {
    	TFT_fillRectangle(0, y, 128, 4, COLOR_WHITE);
    }
    else
    {
    	TFT_fillRectangle(0, y, 128, 4, COLOR_BLACK);
    	TFT_fillRectangle(door*8, y, 24, 4, COLOR_WHITE);
    }
}

void generate_door(void)
{
    door_posx = rand()%14;
}
