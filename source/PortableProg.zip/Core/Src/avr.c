/*
 * avr.c
 *
 *  Created on: Jan 31, 2025
 *      Author: andre
 */

#include "avr.h"

extern FATFS FatFs;
extern FIL Fil;
extern FRESULT Fr,Fres;
extern DIR dir;
extern FILINFO fno;
extern UINT readed, writed;

uint16_t sspi_delay = 10;
uint16_t spi_freq = 9;
uint16_t ext_clk = 0;

extern uint16_t _maxX, _maxY;
extern uint8_t menu, punkt, punkt1;
//Buttons
extern volatile uint8_t up, down, left, right, set;
extern uint8_t main_buff[];
extern char string[];
//
char avr_model[11];
uint32_t avr_fsize;
uint8_t avr_psize;
uint16_t avr_eesize;
uint16_t avr_devnum = 0;

uint8_t sspi_transfer(uint8_t dat)
{
	uint8_t answer = 0x00;
	PGC_LOW

	for(int i=0; i<8; i++)
	{
		if(dat & (1 << (7-i))) PGDO_HIGH
		else PGDO_LOW
		_delay_us(sspi_delay);
		PGC_HIGH
		_delay_us(sspi_delay);
		if(PGD_READ){answer |= 1<<(7-i);}
		PGC_LOW
	}
	return answer;
}

//Enter programming mode
uint8_t avr_progMode(void)
{
	uint8_t answer;
	sspi_transfer(0xAC);
	sspi_transfer(0x53);
	answer = sspi_transfer(0x00);
	sspi_transfer(0x00);
	if(answer!=0x53) return 1;
	return 0;
}

uint8_t avr_enterProg(void)
{
	uint8_t result, try_tim = 0xF;
	AVRCS_LOW
	do
	{
	   result = avr_progMode();
	   try_tim--;
	}
	while(result==1 && try_tim>0 );
	if(try_tim==0)
	{
		AVRCS_HIGH
		return 1;
	}
	return 0;
}

//Отправка команды AVR
uint8_t avr_sendCmd(uint8_t comm, uint16_t arg, uint8_t dat)
{
	sspi_transfer(comm);
	sspi_transfer(arg>>8);
	sspi_transfer(arg&0xFF);
	return sspi_transfer(dat);
}

//Проверка BSY
uint8_t avr_checkBusy(void)
{
	uint8_t try_tim = 100, result;
    do
    {
    	result = avr_sendCmd(0xF0, 0x0000, 0x00);
    	HAL_Delay(2);
    	try_tim--;
    }
    while(result==1 && try_tim>0 );

    if(try_tim==0)return 1;
    return 0;
}

uint8_t avr_readFuses(void)
{
	if(avr_enterProg())
	{
		clear_consoleRow();
		TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
		return 1;
	}
	main_buff[0] = avr_sendCmd(0x50, 0x0000, 0x00); //Low
	main_buff[1] = avr_sendCmd(0x58, 0x0800, 0x00); //High
	main_buff[2] = avr_sendCmd(0x50, 0x0800, 0x00); //Ext
	main_buff[3] = avr_sendCmd(0x58, 0x0000, 0x00); //Lock
	AVRCS_HIGH

	return 0;
}

void draw_avrModel(uint16_t dev)
{
	for(uint8_t i = 0; i < 11; i++) avr_model[i] = avr_devs[i + 17*avr_devnum];
	avr_fsize = avr_devs[13+17*avr_devnum]|(avr_devs[12+17*avr_devnum] << 8)|(avr_devs[11+17*avr_devnum] << 16);
	avr_eesize = avr_devs[15+17*avr_devnum]|(avr_devs[14+17*avr_devnum] << 8);
	avr_psize = avr_devs[16+17*avr_devnum];
	TFT_fillRectangle(55, 32, 80, 8, COLOR_BLACK);
	TFT_drawString(55, 32, avr_model, COLOR_GREEN, COLOR_BLACK, 1);
	//Debug
	clear_consoleRow();
	sprintf(string, "fsize %d", avr_fsize);
	TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
	sprintf(string, "eesize %d", avr_eesize);
	TFT_drawString(95, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
}


//Main avr menu
void avr_menu(void)
{
	punkt = 0;
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "AVR: change operation", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "Get ID", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Device:", COLOR_GREEN, COLOR_BLACK, 1);
	draw_avrModel(avr_devnum);
	TFT_drawString(10, 48, "Read flash", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "Read eeprom", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 80, "Write flash", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 96, "Write eeprom", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 112, "Erase", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 128, "Write Fuse & Lock bits", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 144, "Settings", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 160, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	while(menu == 11)
	{
		cursor_move(10);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Get ID
				{
					if(avr_enterProg())
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
						AVRCS_HIGH
						break;
					}

					main_buff[2] = avr_sendCmd(0x30, 0x0000, 0x00);
					main_buff[0] = avr_sendCmd(0x30, 0x0001, 0x00);
					main_buff[1] = avr_sendCmd(0x30, 0x0002, 0x00);
					AVRCS_HIGH

					draw_25xxId();
					break;
				}
				case 1://Dev model
				{
					avr_devnum++;
					if(avr_devnum >= AVR_DEVCOUNT) avr_devnum = 0;
					draw_avrModel(avr_devnum);
					break;
				}
				case 2://Read flash
				{
					punkt = 0;
					punkt1 = 0;
					menu = 14;
					break;
				}
				case 3://Read eeprom
				{
					punkt = 0;
					punkt1 = 0;
					menu = 15;
					break;
				}
				case 4://Write flash
				{
					punkt = 0;
					punkt1 = 0;
					menu = 16;
					break;
				}
				case 5://Write eeprom
				{
					punkt = 0;
					punkt1 = 0;
					menu = 17;
					break;
				}
				case 6://Erase
				{
					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "Erasing...", COLOR_GREEN, COLOR_BLACK, 1);
					if(avr_enterProg())
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
						AVRCS_HIGH
						break;
					}
					avr_sendCmd(0xAC, 0x8000, 0x00);
					AVRCS_HIGH
					HAL_Delay(500);
					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "Erasing complete", COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 7://Write Fuse & Lock bits
				{
					punkt = 0;
					menu = 12;
					break;
				}
				case 8://Settings
				{
					punkt = 0;
					punkt1 = 0;
					menu = 13;
					break;
				}
				case 9://Return
				{
					punkt = 0;
					menu = 0;
					break;
				}

			}
			set = 0;
		}
		if(left)
		{
			if(punkt == 1)
			{
				if(avr_devnum > 0)
				{
					avr_devnum--;
					draw_avrModel(avr_devnum);
				}
			}
			left = 0;
		}
		if(right)
		{
			if(punkt == 1)
			{
				if(avr_devnum < (AVR_DEVCOUNT-1))
				{
					avr_devnum++;
					draw_avrModel(avr_devnum);
				}
			}
			right = 0;
		}
	}
}

void avr_fuseMenu(void)
{
	punkt = 0;
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "AVR: fuse & lock bits", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "HIGH:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "LOW:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "EXT:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "LOCK:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 80, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 96, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	if(avr_readFuses())
	{
		main_buff[0] = 0;
		main_buff[1] = 0;
		main_buff[2] = 0;
		main_buff[3] = 0;
	}
	draw_hex(46, 16, main_buff[1]);
	draw_hex(46, 32, main_buff[0]);
	draw_hex(46, 48, main_buff[2]);
	draw_hex(46, 64, main_buff[3]);
	clear_fusePointers();


	while(menu == 12)
	{
		cursor_move(6);
		if(set)
		{
			switch(punkt)
			{
				case 0: //High
				{
					punkt1++;
					if(punkt1 > 1) punkt1 = 0;
					clear_fusePointers();
					break;
				}
				case 1: //Low
				{
					punkt1++;
					if(punkt1 > 1) punkt1 = 0;
					clear_fusePointers();
					break;
				}
				case 2: //Ext
				{
					punkt1++;
					if(punkt1 > 1) punkt1 = 0;
					clear_fusePointers();
					break;
				}
				case 3: //Lock
				{
					punkt1++;
					if(punkt1 > 1) punkt1 = 0;
					clear_fusePointers();
					break;
				}
				case 4: //Write
				{
					if(avr_enterProg())
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
						AVRCS_HIGH
						break;
					}
					avr_sendCmd(0xAC, 0xE000, main_buff[3]);//Lock
					HAL_Delay(8);
					avr_sendCmd(0xAC, 0xA400, main_buff[2]);//Ext
					HAL_Delay(8);
				    avr_sendCmd(0xAC, 0xA800, main_buff[1]);//High
				    HAL_Delay(8);
				    avr_sendCmd(0xAC, 0xA000, main_buff[0]);//Low
				    HAL_Delay(8);

					AVRCS_HIGH

					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "Fuse writing complete", COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 5: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 11;
					break;
				}
			}
			set = 0;
		}
		if(left)
		{
			switch(punkt)
			{
				case 0: //High
				{
					if(punkt1 == 0) {if((main_buff[1] & 0xF0) > 0) main_buff[1] = main_buff[1] - 0x10;}
					else {if((main_buff[1] & 0x0F) > 0) main_buff[1] = main_buff[1] - 0x01;}
					draw_hex(46, 16, main_buff[1]);
					break;
				}
				case 1: //Low
				{
					if(punkt1 == 0) {if((main_buff[0] & 0xF0) > 0) main_buff[0] = main_buff[0] - 0x10;}
					else {if((main_buff[0] & 0x0F) > 0) main_buff[0] = main_buff[0] - 0x01;}
					draw_hex(46, 32, main_buff[0]);
					break;
				}
				case 2: //Ext
				{
					if(punkt1 == 0) {if((main_buff[2] & 0xF0) > 0) main_buff[2] = main_buff[2] - 0x10;}
					else {if((main_buff[2] & 0x0F) > 0) main_buff[2] = main_buff[2] - 0x01;}
					draw_hex(46, 48, main_buff[2]);
					break;
				}
				case 3: //Lock
				{
					if(punkt1 == 0) {if((main_buff[3] & 0xF0) > 0) main_buff[3] = main_buff[3] - 0x10;}
					else {if((main_buff[3] & 0x0F) > 0) main_buff[3] = main_buff[3] - 0x01;}
					draw_hex(46, 64, main_buff[3]);
					break;
				}
				default: break;
			}
			left = 0;
		}
		if(right)
		{
			switch(punkt)
			{
				case 0: //High
				{
					if(punkt1 == 0) {if((main_buff[1] & 0xF0) < 0xF0) main_buff[1] = main_buff[1] + 0x10;}
					else {if((main_buff[1] & 0x0F) < 0x0F) main_buff[1] = main_buff[1] + 0x01;}
					draw_hex(46, 16, main_buff[1]);
					break;
				}
				case 1: //Low
				{
					if(punkt1 == 0) {if((main_buff[0] & 0xF0) < 0xF0) main_buff[0] = main_buff[0] + 0x10;}
					else {if((main_buff[0] & 0x0F) < 0x0F) main_buff[0] = main_buff[0] + 0x01;}
					draw_hex(46, 32, main_buff[0]);
					break;
				}
				case 2: //Ext
				{
					if(punkt1 == 0) {if((main_buff[2] & 0xF0) < 0xF0) main_buff[2] = main_buff[2] + 0x10;}
					else {if((main_buff[2] & 0x0F) < 0x0F) main_buff[2] = main_buff[2] + 0x01;}
					draw_hex(46, 48, main_buff[2]);
					break;
				}
				case 3: //Lock
				{
					if(punkt1 == 0) {if((main_buff[3] & 0xF0) < 0xF0) main_buff[3] = main_buff[3] + 0x10;}
					else {if((main_buff[3] & 0x0F) < 0x0F) main_buff[3] = main_buff[3] + 0x01;}
					draw_hex(46, 64, main_buff[3]);
					break;
				}
				default: break;
			}
			right = 0;
		}
	}
}

void clear_fusePointers(void)
{
	TFT_fillRectangle(46, 24, 15, 8, COLOR_BLACK);
	TFT_fillRectangle(46, 40, 15, 8, COLOR_BLACK);
	TFT_fillRectangle(46, 56, 15, 8, COLOR_BLACK);
	TFT_fillRectangle(46, 72, 15, 8, COLOR_BLACK);
	TFT_drawChar(46+(punkt1 * 6), 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(46+(punkt1 * 6), 40, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(46+(punkt1 * 6), 56, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(46+(punkt1 * 6), 72, '^', COLOR_GREEN, COLOR_BLACK, 1);
}

void avr_settingsMenu(void)
{
	punkt = 0;
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "AVR: settings", COLOR_GREEN, COLOR_BLACK, 1);
	sprintf(string, "SPI freq: %d", spi_freq);
	TFT_drawString(10, 16, string, COLOR_GREEN, COLOR_BLACK, 1);
	sprintf(string, "Ext clock: %d", ext_clk);
	TFT_drawString(10, 32, string, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	while(menu == 13)
	{
		cursor_move(3);
		if(set)
		{
			switch(punkt)
			{
				case 0: //SPI freq
				{
					spi_freq++;
					if(spi_freq > 10) spi_freq = 0;
					sspi_delay = 101 - (spi_freq*10);
					TFT_fillRectangle(50, 16, 40, 8, COLOR_BLACK);
					sprintf(string, "SPI freq: %d", spi_freq);
					TFT_drawString(10, 16, string, COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //Ext clk
				{

					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 11;
					break;
				}
			}
			set = 0;
		}
		if(left)
		{
			left = 0;
		}
		if(right)
		{
			right = 0;
		}
	}
}

//Меню чтения AVR Flash
void avr_readFlMenu(void)
{
	uint8_t nam_str[] = "avr_fls0.bin";
	//Progress bar
	uint32_t one_del,del_count;

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "AVR: read flash", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File name:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(80, 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Start reading", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 14)
	{
		cursor_move(3);
		if(set)
		{

			switch(punkt)
			{
				case 0: //F_Name
				{
					punkt1++;
					if(punkt1 >= 8)punkt1 = 0;
					TFT_fillRectangle(80, 24, _maxX - 80, 8, COLOR_BLACK);
					TFT_drawChar(80+(punkt1*6), 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //Start
				{
					Fr = f_open(&Fil, nam_str, FA_CREATE_ALWAYS | FA_WRITE);

					if(Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "SD not mounted", COLOR_GREEN, COLOR_BLACK, 1);
						break;
					}
					else
					{
						//Progress bar
						one_del = avr_fsize/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);
						//Enter prog mode
						if(avr_enterProg())
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
							AVRCS_HIGH
							break;
						}
						//Read cycle
						for(uint32_t i = 0; i < avr_fsize; i += 128)
						{
							if(avr_fsize > 65536) avr_sendCmd(0x4D, (i >> 16),0x00);//Extended address
					    	for(int k = 0; k < 64; k++)
					    	{
					    		main_buff[k*2] = avr_sendCmd(0x20, (k+i/2),0x00);//LOW byte
					    		main_buff[k*2+1] = avr_sendCmd(0x28, (k+i/2),0x00);//HIGH byte
					    	}

							Fr = f_write(&Fil, main_buff, 128, &writed);
							if(Fr != FR_OK)
							{
								clear_consoleRow();
								sprintf(string, "SD write error: %d", Fr);
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								AVRCS_HIGH
								break;
							}
							else //Draw progress bar result
							{
								del_count = i/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
						f_close(&Fil);
						AVRCS_HIGH
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_BLACK);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 11;
					break;
				}
			}
			set = 0;
		}
		if(left)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] > 0x30) nam_str[punkt1]--;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			left = 0;
		}
		if(right)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] < 0x7F) nam_str[punkt1]++;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			right = 0;
		}
	}
}


//Меню чтения AVR Flash
void avr_readEeMenu(void)
{
	uint8_t nam_str[] = "avr_eep0.bin";
	//Progress bar
	uint32_t one_del,del_count;

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "AVR: read eeprom", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File name:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(80, 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Start reading", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 15)
	{
		cursor_move(3);
		if(set)
		{

			switch(punkt)
			{
				case 0: //F_Name
				{
					punkt1++;
					if(punkt1 >= 8)punkt1 = 0;
					TFT_fillRectangle(80, 24, _maxX - 80, 8, COLOR_BLACK);
					TFT_drawChar(80+(punkt1*6), 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //Start
				{
					if(avr_eesize == 0)break;

					Fr = f_open(&Fil, nam_str, FA_CREATE_ALWAYS | FA_WRITE);

					if(Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "SD not mounted", COLOR_GREEN, COLOR_BLACK, 1);
						break;
					}
					else
					{
						//Progress bar
						one_del = avr_fsize/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);
						//Enter prog mode
						if(avr_enterProg())
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
							AVRCS_HIGH
							break;
						}
						//Read cycle
						for(uint32_t i = 0; i < avr_eesize; i += 16)
						{
							for(int k = 0; k < 16; k++)
							{
								main_buff[k+6] = avr_sendCmd(0xA0, (k+i), 0x00);
							}

							Fr = f_write(&Fil, main_buff, 16, &writed);
							if(Fr != FR_OK)
							{
								clear_consoleRow();
								sprintf(string, "SD write error: %d", Fr);
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								AVRCS_HIGH
								break;
							}
							else //Draw progress bar result
							{
								del_count = i/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
						f_close(&Fil);
						AVRCS_HIGH
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_BLACK);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 11;
					break;
				}
			}
			set = 0;
		}
		if(left)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] > 0x30) nam_str[punkt1]--;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			left = 0;
		}
		if(right)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] < 0x7F) nam_str[punkt1]++;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			right = 0;
		}
	}
}

void avr_writeFlMenu(void)
{
	uint8_t fil_changed = 0;
	uint8_t tmp_buff[32];

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "AVR write FLASH", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	Fres = f_opendir(&dir, ""); //Пытаемся открыть root dir
	if(Fres != FR_OK) TFT_drawString(8, _maxY - 8, "SD Card not mounted", COLOR_GREEN, COLOR_BLACK, 1);
	else
	{
		Fr = f_readdir(&dir, &fno);
		if (Fr != FR_OK || fno.fname[0] == 0)
		{
			clear_consoleRow();
			TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
		}
		else
		{
			if(fno.fattrib & AM_DIR)
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
				TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 0;
			}
			else
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 1;
			}
		}
	}

	while(menu == 16)
	{
		cursor_move(3);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Change file
				{
					Fr = f_readdir(&dir, &fno);
					if (Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else if(fno.fname[0] == 0 || fno.fname[0] == '.')
					{
						f_closedir(&dir);
						f_opendir(&dir, "");
						TFT_fillRectangle(88, 16, _maxX - 88, 8, COLOR_BLACK);
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "End of root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else
					{
						clear_consoleRow();
						if(fno.fattrib & AM_DIR)
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
							TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 0;
						}
						else
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 1;
						}
					}

					break;
				}
				case 1: //Write
				{
					if(fil_changed)
					{
						uint32_t offset = 0;
						//Progress bar
						uint32_t one_del, del_count;

						Fr = f_open(&Fil, fno.fname, FA_READ);
						if(Fr != FR_OK)
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "File open error", COLOR_GREEN, COLOR_BLACK, 1);
							break;
						}

						one_del = fno.fsize/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						if(avr_enterProg())
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
							AVRCS_HIGH
							break;
						}

						while(1)
						{
							Fr = f_read(&Fil, main_buff, avr_psize*2, &readed);
							if(Fr != FR_OK)
							{
								sprintf(string, "File read error: %d", Fr);
								clear_consoleRow();
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								TFT_fillRectangle(0, _maxY - 16, _maxX, 8, COLOR_BLACK);
								TFT_drawString(8, _maxY - 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							if(readed == 0)//Выходим из цикла
							{
								AVRCS_HIGH
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							if(readed < avr_psize*2) for(int i = 0; i < (avr_psize*2 - readed); i++) main_buff[i+readed] = 0xFF;
							//Writing
							for(int i = 0; i < avr_psize; i++)
							{
								avr_sendCmd(0x40, i, main_buff[i*2]);//LOW Byte
								avr_sendCmd(0x48, i, main_buff[i*2+1]);//HIGH Byte
							}
							if(avr_fsize > 65536) avr_sendCmd(0x4D, (offset >> 16),0x00);//Extended address
							avr_sendCmd(0x4C, (offset & 0xFFFF), 0x00);
							//while(avr_checkBusy());
							HAL_Delay(15);

							offset += avr_psize;

							if(readed < avr_psize*2)//Выходим из цикла
							{
								AVRCS_HIGH
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							else //Рисуем progress bar
							{
								del_count = 2*offset/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
					}
					else
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No changed file", COLOR_GREEN, COLOR_BLACK, 1);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 11;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

void avr_writeEeMenu(void)
{
	uint8_t fil_changed = 0;
	uint8_t tmp_buff[32];

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "AVR write EEPROM", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	Fres = f_opendir(&dir, ""); //Пытаемся открыть root dir
	if(Fres != FR_OK) TFT_drawString(8, _maxY - 8, "SD Card not mounted", COLOR_GREEN, COLOR_BLACK, 1);
	else
	{
		Fr = f_readdir(&dir, &fno);
		if (Fr != FR_OK || fno.fname[0] == 0)
		{
			clear_consoleRow();
			TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
		}
		else
		{
			if(fno.fattrib & AM_DIR)
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
				TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 0;
			}
			else
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 1;
			}
		}
	}

	while(menu == 17)
	{
		cursor_move(3);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Change file
				{
					Fr = f_readdir(&dir, &fno);
					if (Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else if(fno.fname[0] == 0 || fno.fname[0] == '.')
					{
						f_closedir(&dir);
						f_opendir(&dir, "");
						TFT_fillRectangle(88, 16, _maxX - 88, 8, COLOR_BLACK);
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "End of root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else
					{
						clear_consoleRow();
						if(fno.fattrib & AM_DIR)
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
							TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 0;
						}
						else
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 1;
						}
					}

					break;
				}
				case 1: //Write
				{
					if(fil_changed && avr_eesize)
					{
						uint32_t offset = 0;
						//Progress bar
						uint32_t one_del, del_count;

						Fr = f_open(&Fil, fno.fname, FA_READ);
						if(Fr != FR_OK)
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "File open error", COLOR_GREEN, COLOR_BLACK, 1);
							break;
						}

						one_del = fno.fsize/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						if(avr_enterProg())
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "AVR connection error", COLOR_GREEN, COLOR_BLACK, 1);
							AVRCS_HIGH
							break;
						}

						while(1)
						{
							Fr = f_read(&Fil, main_buff, 16, &readed);
							if(Fr != FR_OK)
							{
								sprintf(string, "File read error: %d", Fr);
								clear_consoleRow();
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								TFT_fillRectangle(0, _maxY - 16, _maxX, 8, COLOR_BLACK);
								TFT_drawString(8, _maxY - 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							if(readed == 0)//Выходим из цикла
							{
								AVRCS_HIGH
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}

							//Writing
							for(int i = 0; i < readed; i++)
							{
							    if(main_buff[i]!=0xFF)
							    {
							    	avr_sendCmd(0xC0, offset+i, main_buff[i]);
							    	HAL_Delay(12);
							    }
							}
							offset += readed;

							if(readed < 16)//Выходим из цикла
							{
								AVRCS_HIGH
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							else //Рисуем progress bar
							{
								del_count = offset/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
					}
					else
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No changed file", COLOR_GREEN, COLOR_BLACK, 1);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 11;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}
