/*
 * ili9225.c
 *
 *  Created on: 10 ���. 2019 �.
 *      Author: andre
 */
#include "ili9225.h"

#include <limits.h>

//extern SPI_HandleTypeDef hspi1;

// Many (but maybe not all) non-AVR board installs define macros
// for compatibility with existing PROGMEM-reading AVR code.
// Do our own checks and defines here for good measure...

#ifndef pgm_read_byte
 #define pgm_read_byte(addr) (*(const unsigned char *)(addr))
#endif
#ifndef pgm_read_word
 #define pgm_read_word(addr) (*(const unsigned short *)(addr))
#endif
#ifndef pgm_read_dword
 #define pgm_read_dword(addr) (*(const unsigned long *)(addr))
#endif

// Pointers are a peculiar case...typically 16-bit on AVR boards,
// 32 bits elsewhere.  Try to accommodate both...

#if !defined(__INT_MAX__) || (__INT_MAX__ > 0xFFFF)
 #define pgm_read_pointer(addr) ((void *)pgm_read_dword(addr))
#else
 #define pgm_read_pointer(addr) ((void *)pgm_read_word(addr))
#endif


uint16_t textcolor, textbgcolor;
uint8_t  _orientation, _brightness, textsize;
uint16_t _maxX, _maxY, _bgColor, cursor_y,cursor_x;
bool wrap;


uint16_t min(uint16_t a,uint16_t b)
{
     if(a<b){return a;}
     else{return b;}
}

////////////////////////////////////////////////////////////////////
void _writeCommand16(uint16_t command) {
     DC_LOW();
     CS_LOW();
#ifdef LCD_SPI1
/*
     while(!(SPI1->SR & SPI_SR_TXE));
     SPI1->DR = (command >> 8);
     while(!(SPI1->SR & SPI_SR_RXNE));
     (void)SPI1->DR;
     while(!(SPI1->SR & SPI_SR_TXE));
     SPI1->DR = (command&0xFF);
     while(!(SPI1->SR & SPI_SR_RXNE));
     (void)SPI1->DR;
*/
     uint8_t tmp[2];
     tmp[0] = command>>8;
     tmp[1] = command&0xFF;
     HAL_SPI_Transmit(&hspi1, tmp, 2, 10);

#endif
#ifdef LCD_SPI2
     while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE)==RESET);
     SPI2->DR = (command>>8);
     while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE)==RESET);
     SPI2->DR = (command&0xFF);
#endif

     CS_HIGH();
}

void _writeData16(uint16_t data) {
            DC_HIGH();
            CS_LOW();
#ifdef LCD_SPI1

     while(!(SPI1->SR & SPI_SR_TXE));
     SPI1->DR = (data>>8);
     while(!(SPI1->SR & SPI_SR_RXNE));
     (void)SPI1->DR;
     while(!(SPI1->SR & SPI_SR_TXE));
     SPI1->DR = (data&0xFF);
     while(!(SPI1->SR & SPI_SR_RXNE));
     (void)SPI1->DR;
     /*
     uint8_t tmp[2];
     tmp[0] = data>>8;
     tmp[1] = data&0xFF;
     HAL_SPI_Transmit(&hspi1, tmp, 2, 10);

     */
#endif
#ifdef LCD_SPI2
     while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE)==RESET);
     SPI2->DR = (data>>8);
     while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE)==RESET);
     SPI2->DR = (data&0xFF);
#endif
        CS_HIGH();

}


        void _writeRegister(uint16_t reg, uint16_t data) {
            _writeCommand16(reg);
            _writeData16(data);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void TFT_begin(void)
{
	_orientation = 0;
	_maxX = ILI9225_LCD_WIDTH - 1;
	_maxY = ILI9225_LCD_HEIGHT -1;
	_bgColor = COLOR_WHITE;


    // Initialization Code
        CS_HIGH();
        HAL_Delay(1);
        RST_LOW(); // Pull the reset pin low to reset ILI9225
        HAL_Delay(10);
        RST_HIGH(); // Pull the reset pin high to release the ILI9225C from the reset status
        HAL_Delay(50);

    /* Start Initial Sequence */

    /* Set SS bit and direction output from S528 to S1 */

    _writeRegister(ILI9225_POWER_CTRL1, 0x0000); // Set SAP,DSTB,STB
    _writeRegister(ILI9225_POWER_CTRL2, 0x0000); // Set APON,PON,AON,VCI1EN,VC
    _writeRegister(ILI9225_POWER_CTRL3, 0x0000); // Set BT,DC1,DC2,DC3
    _writeRegister(ILI9225_POWER_CTRL4, 0x0000); // Set GVDD
    _writeRegister(ILI9225_POWER_CTRL5, 0x0000); // Set VCOMH/VCOML voltage

    HAL_Delay(40);

    // Power-on sequence

    _writeRegister(ILI9225_POWER_CTRL2, 0x0018); // Set APON,PON,AON,VCI1EN,VC
    _writeRegister(ILI9225_POWER_CTRL3, 0x6121); // Set BT,DC1,DC2,DC3
    _writeRegister(ILI9225_POWER_CTRL4, 0x006F); // Set GVDD   /*007F 0088 */
    _writeRegister(ILI9225_POWER_CTRL5, 0x495F); // Set VCOMH/VCOML voltage
    _writeRegister(ILI9225_POWER_CTRL1, 0x0800); // Set SAP,DSTB,STB

    HAL_Delay(10);

    _writeRegister(ILI9225_POWER_CTRL2, 0x103B); // Set APON,PON,AON,VCI1EN,VC

    HAL_Delay(50);

    _writeRegister(ILI9225_DRIVER_OUTPUT_CTRL, 0x011C); // set the display line number and display direction
    _writeRegister(ILI9225_LCD_AC_DRIVING_CTRL, 0x0100); // set 1 line inversion
    _writeRegister(ILI9225_ENTRY_MODE, 0x1038); // set GRAM write direction and BGR=1.
    _writeRegister(ILI9225_DISP_CTRL1, 0x0000); // Display off
    _writeRegister(ILI9225_BLANK_PERIOD_CTRL1, 0x0808); // set the back porch and front porch
    _writeRegister(ILI9225_FRAME_CYCLE_CTRL, 0x1100); // set the clocks number per line
    _writeRegister(ILI9225_INTERFACE_CTRL, 0x0000); // CPU interface
    _writeRegister(ILI9225_OSC_CTRL, 0x0D01); // Set Osc  /*0e01*/
    _writeRegister(ILI9225_VCI_RECYCLING, 0x0020); // Set VCI recycling
    _writeRegister(ILI9225_RAM_ADDR_SET1, 0x0000); // RAM Address
    _writeRegister(ILI9225_RAM_ADDR_SET2, 0x0000); // RAM Address

    /* Set GRAM area */
    _writeRegister(ILI9225_GATE_SCAN_CTRL, 0x0000);
    _writeRegister(ILI9225_VERTICAL_SCROLL_CTRL1, 0x00DB);
    _writeRegister(ILI9225_VERTICAL_SCROLL_CTRL2, 0x0000);
    _writeRegister(ILI9225_VERTICAL_SCROLL_CTRL3, 0x0000);
    _writeRegister(ILI9225_PARTIAL_DRIVING_POS1, 0x00DB);
    _writeRegister(ILI9225_PARTIAL_DRIVING_POS2, 0x0000);
    _writeRegister(ILI9225_HORIZONTAL_WINDOW_ADDR1, 0x00AF);
    _writeRegister(ILI9225_HORIZONTAL_WINDOW_ADDR2, 0x0000);
    _writeRegister(ILI9225_VERTICAL_WINDOW_ADDR1, 0x00DB);
    _writeRegister(ILI9225_VERTICAL_WINDOW_ADDR2, 0x0000);

    /* Set GAMMA curve */
    _writeRegister(ILI9225_GAMMA_CTRL1, 0x0000);
    _writeRegister(ILI9225_GAMMA_CTRL2, 0x0808);
    _writeRegister(ILI9225_GAMMA_CTRL3, 0x080A);
    _writeRegister(ILI9225_GAMMA_CTRL4, 0x000A);
    _writeRegister(ILI9225_GAMMA_CTRL5, 0x0A08);
    _writeRegister(ILI9225_GAMMA_CTRL6, 0x0808);
    _writeRegister(ILI9225_GAMMA_CTRL7, 0x0000);
    _writeRegister(ILI9225_GAMMA_CTRL8, 0x0A00);
    _writeRegister(ILI9225_GAMMA_CTRL9, 0x0710);
    _writeRegister(ILI9225_GAMMA_CTRL10, 0x0710);

    _writeRegister(ILI9225_DISP_CTRL1, 0x0012);

    HAL_Delay(50);

    _writeRegister(ILI9225_DISP_CTRL1, 0x1017);

    TFT_clear();
}


void _spiWrite(uint8_t b)
{
#ifdef LCD_SPI1
	HAL_SPI_Transmit(&hspi1, (uint8_t*)&b, 1, 10);
#else
	spi_transfer(b);
#endif
}


void _orientCoordinates(uint16_t x1, uint16_t y1) {

    switch (_orientation) {
    case 0:  // ok
        break;
    case 1: // ok
        y1 = _maxY - y1-1;
        _swap(x1, y1);
        break;
    case 2: // ok
        x1 = _maxX - x1-1;
        y1 = _maxY - y1-1;
        break;
    case 3: // ok
        x1 = _maxX - x1-1;
        _swap(x1, y1);
        break;
    }
}

void TFT_setWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {

	uint16_t w;

    switch (_orientation) {
    case 0:  // ok
        break;
    case 1: // ok
        y0 = _maxY - y0 - 1;
        w = x0; x0 = y0; y0 = w;
        break;
    case 2: // ok
        x0 = _maxX - x0 - 1;
        y0 = _maxY - y0 - 1;
        break;
    case 3: // ok
        x0 = _maxX - x0 - 1;
        w = x0; x0 = y0; y0 = w;
        break;
    }

    switch (_orientation) {
    case 0:  // ok
        break;
    case 1: // ok
        y1 = _maxY - y1 - 1;
        w = x1; x1 = y1; y1 = w;
        break;
    case 2: // ok
        x1 = _maxX - x1 - 1;
        y1 = _maxY - y1 - 1;
        break;
    case 3: // ok
        x1 = _maxX - x1 - 1;
        w = x1; x1 = y1; y1 = w;
        break;
    }

	    if (x1<x0) {w=x0; x0=x1;x1=w;}
	    if (y1<y0) {w=y0; y0=y1;y1=w;}

	    _writeRegister(ILI9225_HORIZONTAL_WINDOW_ADDR1,x1);
	    _writeRegister(ILI9225_HORIZONTAL_WINDOW_ADDR2,x0);

	    _writeRegister(ILI9225_VERTICAL_WINDOW_ADDR1,y1);
	    _writeRegister(ILI9225_VERTICAL_WINDOW_ADDR2,y0);

	    _writeRegister(ILI9225_RAM_ADDR_SET1,x0);
	    _writeRegister(ILI9225_RAM_ADDR_SET2,y0);

	    _writeCommand16(0x0022);
}


void TFT_resetWindow(void) {
    _writeRegister(ILI9225_HORIZONTAL_WINDOW_ADDR1, 0x00AF);
    _writeRegister(ILI9225_HORIZONTAL_WINDOW_ADDR2, 0x0000);
    _writeRegister(ILI9225_VERTICAL_WINDOW_ADDR1, 0x00DB);
    _writeRegister(ILI9225_VERTICAL_WINDOW_ADDR2, 0x0000);

}

void TFT_clear() {
    uint8_t old = _orientation;
    TFT_setOrientation(0);
    TFT_fillRectangle(0, 0, _maxX, _maxY, COLOR_WHITE);
    TFT_setOrientation(old);
    HAL_Delay(10);
}


void TFT_invert(boolean flag) {

    if(flag){
	_writeCommand16(ILI9225C_INVON);
    }
    else{_writeCommand16(ILI9225C_INVOFF);}
    //_writeCommand(0x00, flag ? ILI9225C_INVON : ILI9225C_INVOFF);

}



void TFT_setDisplay(boolean flag) {
    if (flag) {

        _writeRegister(0x00ff, 0x0000);
        _writeRegister(ILI9225_POWER_CTRL1, 0x0000);

        HAL_Delay(50);

        _writeRegister(ILI9225_DISP_CTRL1, 0x1017);

        HAL_Delay(200);
    } else {

        _writeRegister(0x00ff, 0x0000);
        _writeRegister(ILI9225_DISP_CTRL1, 0x0000);

        HAL_Delay(50);

        _writeRegister(ILI9225_POWER_CTRL1, 0x0003);

        HAL_Delay(200);
    }
}


void TFT_setOrientation(uint8_t orientation) {

    _orientation = orientation % 4;

    switch (_orientation) {
    case 0:
        _maxX = ILI9225_LCD_WIDTH;
        _maxY = ILI9225_LCD_HEIGHT;

        break;
    case 1:
        _maxX = ILI9225_LCD_HEIGHT;
        _maxY = ILI9225_LCD_WIDTH;

        break;
    case 2:
        _maxX = ILI9225_LCD_WIDTH;
        _maxY = ILI9225_LCD_HEIGHT;

        break;
    case 3:
        _maxX = ILI9225_LCD_HEIGHT;
        _maxY = ILI9225_LCD_WIDTH;

        break;
    }
}


uint8_t TFT_getOrientation() {
    return _orientation;
}

void TFT_fillScreen(uint16_t color)
{
	TFT_setWindow(0, 0, _maxX, _maxY);
	for(uint32_t i = 0; i < (_maxX*_maxY); i ++) _writeData16(color);

}


void TFT_drawRectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color) {

	TFT_drawLine(x1, y1, x1, y2, color);
	TFT_drawLine(x1, y1, x2, y1, color);
	TFT_drawLine(x1, y2, x2, y2, color);
	TFT_drawLine(x2, y1, x2, y2, color);
	TFT_resetWindow();
}


void TFT_fillRectangle(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
	  // rudimentary clipping (drawChar w/big text requires this)
	  // rudimentary clipping (drawChar w/big text requires this)
	  if((x >= _maxX) || (y >= _maxY)) return;
	  //if((x + w - 1) >= _maxX)  return;
	  //if((y + h - 1) >= _maxY) return;

	TFT_setWindow(x,y,x+w-1,y+h-1);
	  for(y=h; y>0; y--) {
	    for(x=w; x>0; x--) {
	    	_writeData16(color);
	    }
   }
	TFT_resetWindow();
}


void TFT_drawCircle(uint16_t x0, uint16_t y0, uint16_t r, uint16_t color) {

    int16_t f = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x = 0;
    int16_t y = r;

    TFT_drawPixel(x0, y0 + r, color);
    TFT_drawPixel(x0, y0-  r, color);
    TFT_drawPixel(x0 + r, y0, color);
    TFT_drawPixel(x0 - r, y0, color);

    while (x<y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;

        TFT_drawPixel(x0 + x, y0 + y, color);
        TFT_drawPixel(x0 - x, y0 + y, color);
        TFT_drawPixel(x0 + x, y0 - y, color);
        TFT_drawPixel(x0 - x, y0 - y, color);
        TFT_drawPixel(x0 + y, y0 + x, color);
        TFT_drawPixel(x0 - y, y0 + x, color);
        TFT_drawPixel(x0 + y, y0 - x, color);
        TFT_drawPixel(x0 - y, y0 - x, color);
    }
}


void drawCircleHelper( int16_t x0, int16_t y0, int16_t r, uint8_t cornername, uint16_t color) {
  int16_t f     = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x     = 0;
  int16_t y     = r;

  while (x<y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f     += ddF_y;
    }
    x++;
    ddF_x += 2;
    f     += ddF_x;
    if (cornername & 0x4) {
      TFT_drawPixel(x0 + x, y0 + y, color);
      TFT_drawPixel(x0 + y, y0 + x, color);
    }
    if (cornername & 0x2) {
    	TFT_drawPixel(x0 + x, y0 - y, color);
    	TFT_drawPixel(x0 + y, y0 - x, color);
    }
    if (cornername & 0x8) {
    	TFT_drawPixel(x0 - y, y0 + x, color);
    	TFT_drawPixel(x0 - x, y0 + y, color);
    }
    if (cornername & 0x1) {
    	TFT_drawPixel(x0 - y, y0 - x, color);
    	TFT_drawPixel(x0 - x, y0 - y, color);
    }
  }
}

void TFT_fillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color) {
  drawFastVLine(x0, y0-r, 2*r+1, color);
  fillCircleHelper(x0, y0, r, 3, 0, color);
}

// Used to do circles and roundrects
void fillCircleHelper(int16_t x0, int16_t y0, int16_t r, uint8_t cornername, int16_t delta, uint16_t color) {

  int16_t f     = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x     = 0;
  int16_t y     = r;

  while (x<y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f     += ddF_y;
    }
    x++;
    ddF_x += 2;
    f     += ddF_x;

    if (cornername & 0x1) {
      drawFastVLine(x0+x, y0-y, 2*y+1+delta, color);
      drawFastVLine(x0+y, y0-x, 2*x+1+delta, color);
    }
    if (cornername & 0x2) {
      drawFastVLine(x0-x, y0-y, 2*y+1+delta, color);
      drawFastVLine(x0-y, y0-x, 2*x+1+delta, color);
    }
  }
}


void TFT_drawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color) {

	int16_t steep;
	if(abs(y1 - y0) > abs(x1 - x0)){steep = 1;}
	else{steep = 0;}

	  if (steep) {
	    _swap(x0, y0);
	    _swap(x1, y1);
	  }

	  if (x0 > x1) {
	    _swap(x0, x1);
	    _swap(y0, y1);
	  }

	  int16_t dx, dy;
	  dx = x1 - x0;
	  dy = abs(y1 - y0);

	  int16_t err = dx / 2;
	  int16_t ystep;

	  if (y0 < y1) {
	    ystep = 1;
	  } else {
	    ystep = -1;
	  }

	  for (; x0<=x1; x0++) {
	    if (steep) {
	      TFT_drawPixel(y0, x0, color);
	    } else {
	      TFT_drawPixel(x0, y0, color);
	    }
	    err -= dy;
	    if (err < 0) {
	      y0 += ystep;
	      err += dx;
	    }
	  }
}

void drawFastVLine(int16_t x0, int16_t y0, int16_t h, uint16_t color)
{
	  // Rudimentary clipping
	  if((x0 >= _maxX) || (y0 >= _maxY)) return;
	  if((y0+h-1) >= _maxY) h = _maxY-y0;
	  TFT_setWindow(x0, y0, x0, y0+h-1);

	  while (h--) {
	    _writeData16(color);
	  }

}


void drawFastHLine(int16_t x0, int16_t y0, int16_t w, uint16_t color)
{

	  // Rudimentary clipping
	  if((x0 >= _maxX) || (y0 >= _maxY)) return;
	  if((x0+w-1) >= _maxX)  w = _maxX-x0;
	  TFT_setWindow(x0, y0, x0+w-1, y0);
	  while (w--)
	  {
		  _writeData16(color);
	  }
}

void TFT_drawPixel(uint16_t x1, uint16_t y1, uint16_t color) {

    if((x1 >= _maxX) || (y1 >= _maxY)) return;


    TFT_setWindow(x1, y1, x1+1, y1+1);
    //_orientCoordinates(x1, y1);

    _writeData16(color);

}


uint16_t TFT_maxX() {
    return _maxX;
}


uint16_t TFT_maxY() {
    return _maxY;
}


uint16_t TFT_setColor(uint8_t red8, uint8_t green8, uint8_t blue8) {
    // rgb16 = red5 green6 blue5
    return (red8 >> 3) << 11 | (green8 >> 2) << 5 | (blue8 >> 3);
}


void TFT_splitColor(uint16_t rgb, uint8_t red, uint8_t green, uint8_t blue) {
    // rgb16 = red5 green6 blue5
    red   = (rgb & 0b1111100000000000) >> 11 << 3;
    green = (rgb & 0b0000011111100000) >>  5 << 2;
    blue  = (rgb & 0b0000000000011111)       << 3;
}


void TFT_drawTriangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t x3, uint16_t y3, uint16_t color) {

    TFT_drawLine(x1, y1, x2, y2, color);
    TFT_drawLine(x2, y2, x3, y3, color);
    TFT_drawLine(x3, y3, x1, y1, color);

}


void TFT_fillTriangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t x3, uint16_t y3, uint16_t color) {

    uint16_t a, b, y, last;

    // Sort coordinates by Y order (y3 >= y2 >= y1)
    if (y1 > y2) {
        _swap(y1, y2); _swap(x1, x2);
    }
    if (y2 > y3) {
        _swap(y3, y2); _swap(x3, x2);
    }
    if (y1 > y2) {
        _swap(y1, y2); _swap(x1, x2);
    }


    if (y1 == y3) { // Handle awkward all-on-same-line case as its own thing
        a = b = x1;
        if (x2 < a)      a = x2;
        else if (x2 > b) b = x2;
        if (x3 < a)      a = x3;
        else if (x3 > b) b = x3;
        TFT_drawLine(a, y1, b, y1, color);
        return;
    }

    int16_t dx11 = x2 - x1,
            dy11 = y2 - y1,
            dx12 = x3 - x1,
            dy12 = y3 - y1,
            dx22 = x3 - x2,
            dy22 = y3 - y2;
    int32_t sa   = 0,
            sb   = 0;

    // For upper part of triangle, find scanline crossings for segments
    // 0-1 and 0-2.  If y2=y3 (flat-bottomed triangle), the scanline y2
    // is included here (and second loop will be skipped, avoiding a /0
    // error there), otherwise scanline y2 is skipped here and handled
    // in the second loop...which also avoids a /0 error here if y1=y2
    // (flat-topped triangle).
    if (y2 == y3) last = y2;   // Include y2 scanline
    else          last = y2 - 1; // Skip it

    for (y = y1; y <= last; y++) {
        a   = x1 + sa / dy11;
        b   = x1 + sb / dy12;
        sa += dx11;
        sb += dx12;
        /* longhand:
        a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
        b = x1 + (x3 - x1) * (y - y1) / (y3 - y1);
        */
        if (a > b) _swap(a,b);
        TFT_drawLine(a, y, b, y, color);
    }

    // For lower part of triangle, find scanline crossings for segments
    // 0-2 and 1-2.  This loop is skipped if y2=y3.
    sa = dx22 * (y - y2);
    sb = dx12 * (y - y1);
    for (; y<=y3; y++) {
        a   = x2 + sa / dy22;
        b   = x1 + sb / dy12;
        sa += dx22;
        sb += dx12;
        /* longhand:
        a = x2 + (x3 - x2) * (y - y2) / (y3 - y2);
        b = x1 + (x3 - x1) * (y - y1) / (y3 - y1);
        */
        if (a > b) _swap(a,b);
        TFT_drawLine(a, y, b, y, color);
    }
}


// TEXT- AND CHARACTER-HANDLING FUNCTIONS ----------------------------------

void TFT_drawChar(int16_t x, int16_t y, char c, uint16_t color, uint16_t bg, uint8_t size) {

  if((x >= _maxX)            || // Clip right
     (y >= _maxY)           || // Clip bottom
     ((x + 6 * size - 1) < 0) || // Clip left
     ((y + 8 * size - 1) < 0))   // Clip top
    return;

  for (int8_t i=0; i<6; i++ ) {
    uint8_t line;
    if (i == 5)
      line = 0x0;
    else
      line = pgm_read_byte(font+(c*5)+i);
    for (int8_t j = 0; j<8; j++) {
      if (line & 0x1) {
        if (size == 1) // default size
          TFT_drawPixel(x+i, y+j, color);
        else {  // big size
          TFT_fillRectangle(x+(i*size), y+(j*size), size, size, color);
        }
      } else if (bg != color) {
        if (size == 1) // default size
          TFT_drawPixel(x+i, y+j, bg);
        else {  // big size
          TFT_fillRectangle(x+i*size, y+j*size, size, size, bg);
        }
      }
      line >>= 1;
    }
  }
}

void TFT_drawString(int16_t x, int16_t y, char *c, uint16_t color, uint16_t bg, uint8_t size)
{
	uint16_t pos_x = x;
	uint16_t pos_y = y;
	uint8_t spc_x,spc_y;
	int i = 0;

	//������ ������� � �������� ����� ���������
	if(size==1) {spc_x=6; spc_y=8;}
	else if(size==2) {spc_x=12; spc_y=16;}
	else if(size==3) {spc_x=16; spc_y=23;}
	else {spc_x=18; spc_y=20;}


		while(c[i])
		{
			TFT_drawChar(pos_x,pos_y,c[i++],color,bg,size);
			pos_x += spc_x;
			if(pos_x>(_maxX-spc_x)) {pos_x=0; pos_y+=spc_y;}
			if(pos_y>(_maxY-spc_y)){pos_y=0; pos_x=0;}
		}

}

void setCursor(int16_t x, int16_t y) {
  cursor_x = x;
  cursor_y = y;
}

void setTextSize(uint8_t s) {
  textsize = (s > 0) ? s : 1;
}

void setTextColor(uint16_t c) {
  // For 'transparent' background, we'll set the bg
  // to the same as fg instead of using a flag
  textcolor = textbgcolor = c;
}

void setTextColor1(uint16_t c, uint16_t b) {
  textcolor   = c;
  textbgcolor = b;
}

void setTextWrap(boolean w) {
  wrap = w;
}


// Return the size of the display (per current rotation)
uint16_t width(void) {
  return TFT_maxX();
}

uint16_t height(void) {
  return _maxY;
}




