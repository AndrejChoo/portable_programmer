/*
 * progger.c
 *
 *  Created on: Jan 21, 2025
 *      Author: andre
 */

#include "progger.h"


uint8_t spi_transfer(uint8_t dat)
{
	uint8_t answ;
	HAL_SPI_TransmitReceive(&hspi4, (uint8_t*)&dat, (uint8_t*)&answ, 1, 10);
	return answ;
}

//Spi flash 25xx
void fl25xx_getId(uint8_t *dat)
{
	F25CS_LOW
	spi_transfer(0x9F);
	dat[2] = spi_transfer(0x00);
	dat[0] = spi_transfer(0x00);
	dat[1] = spi_transfer(0x00);
	F25CS_HIGH

}

void fl25xx_erase(void)
{
	F25CS_LOW
	spi_transfer(0x06); //Write enable
	F25CS_HIGH
	//While !WEL
	while(!(fl25xx_readReg(0x05) & (1 << 1)));

	F25CS_LOW
	spi_transfer(0xC7); //Erase
	F25CS_HIGH
	//While BSY
	while(fl25xx_readReg(0x05) & (1 << 0));
}

uint8_t fl25xx_readReg(uint8_t reg)
{
	uint8_t tmp;
	F25CS_LOW
	spi_transfer(reg);
	tmp = spi_transfer(0x00);
	F25CS_HIGH
	return tmp;
}
