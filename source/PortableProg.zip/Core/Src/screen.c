/*
 * screen.c
 *
 *  Created on: Jan 20, 2025
 *      Author: andre
 */

#include "screen.h"


extern uint16_t _maxX, _maxY;
FATFS FatFs;
FIL Fil;
FRESULT Fr,Fres;
DIR dir;
FILINFO fno;
UINT readed, writed;

uint8_t menu = 0, punkt = 0, punkt1 = 0;
//Buttons
extern volatile uint8_t up, down, left, right, set;

static const char symb[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
char string[25];
uint8_t main_buff[512];
uint32_t f_size;

//24cxx
uint16_t i2c_dev = 1;

//93xx
uint8_t mw_dev = 0, mw_addsize = 6;
uint8_t *mw_devs = "93C46";

//Перевод байта в два символа
uint16_t hex_toStr(uint8_t h)
{
	uint8_t hByte = symb[h >> 4],lByte = symb[h & 0xF];
	return (hByte << 8) | lByte;
}

//Начальная заставка
void start_screen(void)
{
	uint16_t centrX = _maxX/2, centrY = _maxY/2;
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(centrX - 30, centrY - 20, "Loading...", COLOR_WHITE, COLOR_BLACK, 1);
	TFT_fillRectangle(centrX - 50, centrY - 8, 100, 16, COLOR_WHITE);
	for(int i = 0; i < 100; i++)
	{
		drawFastVLine(centrX - 50 + i, centrY - 8, 16, COLOR_GREEN);
		HAL_Delay(10);
	}
	TFT_fillScreen(COLOR_BLACK);
	Fr = f_mount(&FatFs, "", 1);
	if(Fr != FR_OK) TFT_drawString(10, _maxY - 32, "SD Card not mounted", COLOR_GREEN, COLOR_BLACK, 1);
	else TFT_drawString(10, _maxY - 32, "SD Card mount ok", COLOR_GREEN, COLOR_BLACK, 1);

	HAL_Delay(1000);

	menu = 0;
}

void draw_hex(uint16_t x, uint16_t y, uint8_t h8)
{
	TFT_drawChar(x, y, symb[(h8 >> 4) & 0xF], COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(x+6, y, symb[h8 & 0xF], COLOR_GREEN, COLOR_BLACK, 1);
}

//Очищаем колонку с указателем строки
void clear_changeColumn(void)
{
	TFT_fillRectangle(0, 0, 8, _maxY, COLOR_BLACK);
}

void clear_consoleRow(void)
{
	TFT_fillRectangle(0, _maxY - 8, _maxX, 8, COLOR_BLACK);
}

void cursor_move(uint8_t punkt_cnt)
{
	if(up)
	{
		if(punkt > 0)
		{
			punkt--;
			clear_changeColumn();
			TFT_drawChar(0, (punkt + 1) *16, '>', COLOR_GREEN, COLOR_BLACK, 1);
		}
		up = 0;
	}
	if(down)
	{
		if(punkt < punkt_cnt - 1)
		{
			punkt++;
			clear_changeColumn();
			TFT_drawChar(0, (punkt + 1) *16, '>', COLOR_GREEN, COLOR_BLACK, 1);
		}
		down = 0;
	}
}

//Начальное меню выбора устройства
void device_menu(void)
{
	punkt = 0;
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(20, 1, "Change device type", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "SPI Flash 25xx", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "I2C EEPROM 24xx", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "MICROWIRE 93xx", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "AVR MCU", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 80, "Bonus", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	while(menu == 0)
	{
		cursor_move(5);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Spi flash
				{
					menu = 1;
					break;
				}
				case 1: //I2c eeprom
				{
					menu = 5;
					break;
				}
				case 2: //Microwire
				{
					menu = 8;
					break;
				}
				case 3: //AVR
				{
					menu = 11;
					break;
				}
				case 4: //Games
				{
					menu = 255;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

//Главное меню 25XX SPI Flash
void fl25xx_menu(void)
{
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "25XX: change operation", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "Get ID", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Read", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "Erase", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 80, "Read SREG", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 96, "Write SREG", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 112, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 1)
	{
		cursor_move(7);
		if(set)
		{
			set = 0;
			switch(punkt)
			{
				case 0: //Get ID
				{
					fl25xx_getId(main_buff);
					draw_25xxId();
					break;
				}
				case 1: //Read
				{
					punkt = 0;
					menu = 2;
					break;
				}
				case 2: //Write
				{
					punkt = 0;
					punkt1 = 0;
					menu = 4;
					break;
				}
				case 3: //Erase
				{
					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "Erasing...", COLOR_GREEN, COLOR_BLACK, 1);
					fl25xx_erase();
					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "Chip erased", COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 4: //Read SREG
				{
					draw_25xxSreg();
					break;
				}
				case 5: //Write SREG
				{
					punkt = 0;
					punkt1 = 0;
					menu = 3;
					break;
				}
				case 6: //Return
				{
					punkt = 0;
					menu = 0;
					break;
				}
			}
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}


void draw_25xxId(void)
{	char tmp[7];
	tmp[0] = hex_toStr(main_buff[2]) >> 8;
	tmp[1] = hex_toStr(main_buff[2]) & 0xFF;
	tmp[2] = hex_toStr(main_buff[0]) >> 8;
	tmp[3] = hex_toStr(main_buff[0]) & 0xFF;
	tmp[4] = hex_toStr(main_buff[1]) >> 8;
	tmp[5] = hex_toStr(main_buff[1]) & 0xFF;
	tmp[6] = '\0';

	clear_consoleRow();
	TFT_drawString(8, _maxY - 8, "Dev Id -> ", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(80, _maxY - 8, tmp, COLOR_GREEN, COLOR_BLACK, 1);
}

void draw_25xxSreg(void)
{
	uint8_t sreg1 = fl25xx_readReg(0x05);
	uint8_t sreg2 = fl25xx_readReg(0x35);
	char tmp[6];

	tmp[0] = hex_toStr(sreg2) >> 8;
	tmp[1] = hex_toStr(sreg2) & 0xFF;
	tmp[2] = ' ';
	tmp[3] = hex_toStr(sreg1) >> 8;
	tmp[4] = hex_toStr(sreg1) & 0xFF;
	tmp[5] = '\0';
	clear_consoleRow();
	TFT_drawString(8, _maxY - 8, "25XX SREG 2,1 -> ", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(106, _maxY - 8, tmp, COLOR_GREEN, COLOR_BLACK, 1);
}

//Меню чтения SPI Flash
void fl25xx_readMenu(void)
{
	uint16_t fsz = 1;
	f_size = fsz * 131072;
	uint8_t nam_str[] = "filename.bin";
	//Progress bar
	uint32_t one_del,del_count;

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "25XX: read settings", COLOR_GREEN, COLOR_BLACK, 1);
	sprintf(string, "F_Size %d Mbit", fsz);
	TFT_drawString(10, 16, string, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "File name:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(80, 32, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(80, 40, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Start", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 2)
	{
		cursor_move(4);
		if(set)
		{
			set = 0;
			switch(punkt)
			{
				case 0: //F_Size
				{
					fsz = fsz * 2;
					if(fsz > 256) fsz = 1;

					f_size = fsz * 131072;
					sprintf(string, "F_Size %d Mbit", fsz);
					TFT_fillRectangle(10, 16, _maxX - 10, 8, COLOR_BLACK);
					TFT_drawString(10, 16, string, COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //F_Name
				{
					punkt1++;
					if(punkt1 >= 8)punkt1 = 0;
					TFT_fillRectangle(80, 40, _maxX - 80, 8, COLOR_BLACK);
					TFT_drawChar(80+(punkt1*6), 40, '^', COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 2: //Start
				{
					Fr = f_open(&Fil, nam_str, FA_CREATE_ALWAYS | FA_WRITE);

					if(Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "SD not mounted", COLOR_GREEN, COLOR_BLACK, 1);
						break;
					}
					else
					{
						//Progress bar
						one_del = f_size/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						for(uint32_t i = 0; i < f_size; i += 256)
						{
							F25CS_LOW
							spi_transfer(0x03);
							spi_transfer((i >> 16) & 0xFF);
							spi_transfer((i >> 8) & 0xFF);
							spi_transfer(i & 0xFF);
							HAL_SPI_Receive(&hspi4, main_buff, 256, 100);
							F25CS_HIGH

							Fr = f_write(&Fil, main_buff, 256, &writed);
							if(Fr != FR_OK)
							{
								clear_consoleRow();
								sprintf(string, "SD write error: %d", Fr);
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							else //Draw progress bar result
							{
								del_count = i/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
						f_close(&Fil);
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_BLACK);
					}
					break;
				}
				case 3: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 1;
					break;
				}
			}
		}
		if(left)
		{
			left = 0;
			if(punkt==1)
			{
				if(nam_str[punkt1] > 0x30) nam_str[punkt1]--;
				TFT_drawString(80, 32, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
		}
		if(right)
		{
			right = 0;
			if(punkt==1)
			{
				if(nam_str[punkt1] < 0x7F) nam_str[punkt1]++;
				TFT_drawString(80, 32, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
		}
	}
}

//Меню записи SREG
void fl25xx_writeSregMenu(void)
{
	uint8_t sreg1 = 0, sreg2 = 0;
	punkt = 0;
	punkt1 = 0;

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "25XX: write SREG", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "SREG2:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(45, 16, (hex_toStr(sreg2) >> 8), COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(51, 16, (hex_toStr(sreg2) & 0xFF), COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(45, 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "SREG1:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(45, 32, (hex_toStr(sreg1) >> 8), COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(51, 32, (hex_toStr(sreg1) & 0xFF), COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(45, 40, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	while(menu == 3)
	{
		cursor_move(4);
		if(set)
		{
			set = 0;
			switch(punkt)
			{
				case 0: //SREG2
				{
					punkt1++;
					if(punkt1 > 1)punkt1 = 0;
					TFT_fillRectangle(45, 24, _maxX - 45, 8, COLOR_BLACK);
					TFT_drawChar(45+(punkt1*6), 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
					TFT_fillRectangle(45, 40, _maxX - 45, 8, COLOR_BLACK);
					TFT_drawChar(45+(punkt1*6), 40, '^', COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //SREG1
				{
					punkt1++;
					if(punkt1 > 1)punkt1 = 0;
					TFT_fillRectangle(45, 24, _maxX - 45, 8, COLOR_BLACK);
					TFT_drawChar(45+(punkt1*6), 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
					TFT_fillRectangle(45, 40, _maxX - 45, 8, COLOR_BLACK);
					TFT_drawChar(45+(punkt1*6), 40, '^', COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 2: //Write
				{
					F25CS_LOW
					spi_transfer(0x50);
					F25CS_HIGH

					HAL_Delay(50);

					F25CS_LOW
					spi_transfer(0x01);
					spi_transfer(sreg1);
					spi_transfer(sreg2);
					F25CS_HIGH

					HAL_Delay(50);
					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "SREG1,2 written", COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 3: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 1;
					break;
				}
			}
		}
		if(left)
		{
			if(punkt == 0)
			{
				if(punkt1 == 0) sreg2 -= 0x10;
				if(punkt1 == 1) sreg2 -= 0x01;
			}
			if(punkt == 1)
			{
				if(punkt1 == 0) sreg1 -= 0x10;
				if(punkt1 == 1) sreg1 -= 0x01;
			}
			dwaw_25xxSreg1(sreg1, sreg2);
			left = 0;
		}
		if(right)
		{
			if(punkt == 0)
			{
				if(punkt1 == 0) sreg2 += 0x10;
				if(punkt1 == 1) sreg2 += 0x01;
			}
			if(punkt == 1)
			{
				if(punkt1 == 0) sreg1 += 0x10;
				if(punkt1 == 1) sreg1 += 0x01;
			}
			dwaw_25xxSreg1(sreg1, sreg2);
			right = 0;
		}
	}
}

void dwaw_25xxSreg1(uint8_t s1, uint8_t s2)
{
	TFT_fillRectangle(45, 16, _maxX - 45, 8, COLOR_BLACK);
	TFT_fillRectangle(45, 32, _maxX - 45, 8, COLOR_BLACK);
	TFT_drawChar(45, 16, (hex_toStr(s2) >> 8), COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(51, 16, (hex_toStr(s2) & 0xFF), COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(45, 32, (hex_toStr(s1) >> 8), COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(51, 32, (hex_toStr(s1) & 0xFF), COLOR_GREEN, COLOR_BLACK, 1);
}

void fl25xx_writeMenu(void)
{
	uint8_t fil_changed = 0;

	punkt = 0;
	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "24XX: write file", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);

	Fres = f_opendir(&dir, ""); //Пытаемся открыть root dir
	if(Fres != FR_OK) TFT_drawString(8, _maxY - 8, "SD Card not mounted", COLOR_GREEN, COLOR_BLACK, 1);
	else
	{
		Fr = f_readdir(&dir, &fno);
		if (Fr != FR_OK || fno.fname[0] == 0)
		{
			clear_consoleRow();
			TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
		}
		else
		{
			if(fno.fattrib & AM_DIR)
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
				TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 0;
			}
			else
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 1;
			}
		}
	}

	while(menu == 4)
	{
		cursor_move(3);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Change file
				{
					Fr = f_readdir(&dir, &fno);
					if (Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else if(fno.fname[0] == 0 || fno.fname[0] == '.')
					{
						f_closedir(&dir);
						f_opendir(&dir, "");
						TFT_fillRectangle(88, 16, _maxX - 88, 8, COLOR_BLACK);
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "End of root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else
					{
						clear_consoleRow();
						if(fno.fattrib & AM_DIR)
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
							TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 0;
						}
						else
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 1;
						}
					}

					break;
				}
				case 1: //Write
				{
					if(fil_changed)
					{
						uint32_t offset = 0;
						//Progress bar
						uint32_t one_del, del_count;

						Fr = f_open(&Fil, fno.fname, FA_READ);
						if(Fr != FR_OK)
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "File open error", COLOR_GREEN, COLOR_BLACK, 1);
							break;
						}

						one_del = fno.fsize/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						while(1)
						{
							Fr = f_read(&Fil, main_buff, 512, &readed);
							if(Fr != FR_OK)
							{
								sprintf(string, "File read error: %d", Fr);
								clear_consoleRow();
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								TFT_fillRectangle(0, _maxY - 16, _maxX, 8, COLOR_BLACK);
								TFT_drawString(8, _maxY - 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							if(readed < 512) for(int i = 0; i < (512 - readed); i++) main_buff[i+readed] = 0xFF;
							if(readed == 0)//Выходим из цикла
							{
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}

							F25CS_LOW
							spi_transfer(0x06);
							F25CS_HIGH
							while(!(fl25xx_readReg(0x05) & (1 << 1)));

							F25CS_LOW
							spi_transfer(0x02);

							spi_transfer((offset >> 16) & 0xFF);
							spi_transfer((offset >> 8) & 0xFF);
							spi_transfer((offset & 0xFF));
							HAL_SPI_Transmit(&hspi4, main_buff, 512, 100);
							F25CS_HIGH

							while(fl25xx_readReg(0x05) & 0x01); //bit BSY

							offset += 512;

							if(readed < 512)//Выходим из цикла
							{
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							else //Рисуем progress bar
							{
								del_count = offset/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
					}
					else
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No changed file", COLOR_GREEN, COLOR_BLACK, 1);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 1;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

/////////////////////////////////////////i2C EEPROM////////////////////////////////////////////////////
//Главное меню 25XX SPI Flash
void ee24xx_menu(void)
{
	f_size = i2c_dev * 128;

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "24XX: change operation", COLOR_GREEN, COLOR_BLACK, 1);
	if(i2c_dev < 16) sprintf(string, "Chip: 24C0%d",i2c_dev);
	else  sprintf(string, "Chip: 24C%d",i2c_dev);
	TFT_drawString(10, 16, string, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Read", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 5)
	{
		cursor_move(4);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Change chip
				{
					i2c_dev = i2c_dev * 2;
					if(i2c_dev > 256) i2c_dev = 1;
					f_size = i2c_dev * 128;
					TFT_fillRectangle(60, 16, _maxX-60, 8, COLOR_BLACK);
					if(i2c_dev < 16) sprintf(string, "Chip: 24C0%d",i2c_dev);
					else  sprintf(string, "Chip: 24C%d",i2c_dev);
					TFT_drawString(10, 16, string, COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //Read
				{
					punkt = 0;
					menu = 6;
					break;
				}
				case 2: //Write
				{
					punkt = 0;
					menu = 7;
					break;
				}
				case 3: //Return
				{
					punkt = 0;
					menu = 0;
					break;
				}
			}

			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

//Меню чтения SPI Flash
void ee24xx_readMenu(void)
{
	uint8_t nam_str[] = "eep_fil0.bin";
	//Progress bar
	uint32_t one_del,del_count;

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "24XX: read settings", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File name:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(80, 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Start", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 6)
	{
		cursor_move(3);
		if(set)
		{

			switch(punkt)
			{
				case 0: //F_Name
				{
					punkt1++;
					if(punkt1 >= 8)punkt1 = 0;
					TFT_fillRectangle(80, 24, _maxX - 80, 8, COLOR_BLACK);
					TFT_drawChar(80+(punkt1*6), 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //Start
				{
					Fr = f_open(&Fil, nam_str, FA_CREATE_ALWAYS | FA_WRITE);

					if(Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "SD not mounted", COLOR_GREEN, COLOR_BLACK, 1);
						break;
					}
					else
					{
						//Progress bar
						one_del = f_size/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						for(uint32_t i = 0; i < f_size; i += 128)
						{
							if(f_size <= 256)
							{
								HAL_I2C_Mem_Read(&hi2c1, 0xA0, i, 1, main_buff, 128, 100);
							}
							else if(f_size > 256 && f_size <= 2048)
							{
								HAL_I2C_Mem_Read(&hi2c1, (0xA0 | ((i >> 7) & 0x0E)), i, 1, main_buff, 128, 100);
							}
							else
							{
								HAL_I2C_Mem_Read(&hi2c1, 0xA0, i, 2, main_buff, 128, 100);
							}

							Fr = f_write(&Fil, main_buff, 128, &writed);
							if(Fr != FR_OK)
							{
								clear_consoleRow();
								sprintf(string, "SD write error: %d", Fr);
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							else //Draw progress bar result
							{
								del_count = i/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
						f_close(&Fil);
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_BLACK);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 5;
					break;
				}
			}
			set = 0;
		}
		if(left)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] > 0x30) nam_str[punkt1]--;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			left = 0;
		}
		if(right)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] < 0x7F) nam_str[punkt1]++;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			right = 0;
		}
	}
}

void ee24xx_writeMenu(void)
{
	uint8_t fil_changed = 0;
	uint8_t tmp_buff[32];

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "25XX: write file", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	Fres = f_opendir(&dir, ""); //Пытаемся открыть root dir
	if(Fres != FR_OK) TFT_drawString(8, _maxY - 8, "SD Card not mounted", COLOR_GREEN, COLOR_BLACK, 1);
	else
	{
		Fr = f_readdir(&dir, &fno);
		if (Fr != FR_OK || fno.fname[0] == 0)
		{
			clear_consoleRow();
			TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
		}
		else
		{
			if(fno.fattrib & AM_DIR)
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
				TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 0;
			}
			else
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 1;
			}
		}
	}

	while(menu == 7)
	{
		cursor_move(3);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Change file
				{
					Fr = f_readdir(&dir, &fno);
					if (Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else if(fno.fname[0] == 0 || fno.fname[0] == '.')
					{
						f_closedir(&dir);
						f_opendir(&dir, "");
						TFT_fillRectangle(88, 16, _maxX - 88, 8, COLOR_BLACK);
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "End of root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else
					{
						clear_consoleRow();
						if(fno.fattrib & AM_DIR)
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
							TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 0;
						}
						else
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 1;
						}
					}

					break;
				}
				case 1: //Write
				{
					if(fil_changed)
					{
						uint32_t offset = 0;
						//Progress bar
						uint32_t one_del, del_count;

						Fr = f_open(&Fil, fno.fname, FA_READ);
						if(Fr != FR_OK)
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "File open error", COLOR_GREEN, COLOR_BLACK, 1);
							break;
						}

						one_del = fno.fsize/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						while(1)
						{
							Fr = f_read(&Fil, main_buff, 128, &readed);
							if(Fr != FR_OK)
							{
								sprintf(string, "File read error: %d", Fr);
								clear_consoleRow();
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								TFT_fillRectangle(0, _maxY - 16, _maxX, 8, COLOR_BLACK);
								TFT_drawString(8, _maxY - 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							if(readed == 0)//Выходим из цикла
							{
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							if(readed < 128) for(int i = 0; i < (128 - readed); i++) main_buff[i+readed] = 0xFF;
							//Writing
							if(f_size <= 256) //24c01, 24c02 8-байтовая страница
							{
								for(int k = 0; k < 128; k+= 8)
								{
									for(int u = 0; u < 8; u++) tmp_buff[u] = main_buff[u + k];
									HAL_I2C_Mem_Write(&hi2c1, 0xA0, k + offset, 1, tmp_buff, 8, 100);
									HAL_Delay(5);
								}
							}
							else if(f_size > 256 && f_size <= 2048) // 16-байтовая страница
							{
								uint8_t dop_add;

								for(int k = 0; k < 128; k+= 16)
								{
									dop_add = ((offset + k) >> 7) & 0x0E;
									for(int u = 0; u < 16; u++) tmp_buff[u] = main_buff[u + k];
									HAL_I2C_Mem_Write(&hi2c1, (0xA0 | dop_add), k + offset, 1, tmp_buff, 16, 100);
									HAL_Delay(5);
								}
							}
							else
							{
								for(int k = 0; k < 128; k+= 32)
								{
									for(int u = 0; u < 32; u++) tmp_buff[u] = main_buff[u + k];
									HAL_I2C_Mem_Write(&hi2c1, 0xA0, k + offset, 2, tmp_buff, 32, 100);
									HAL_Delay(5);
								}
							}

							offset += 128;

							if(readed < 128)//Выходим из цикла
							{
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							else //Рисуем progress bar
							{
								del_count = offset/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
					}
					else
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No changed file", COLOR_GREEN, COLOR_BLACK, 1);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 5;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

/////////////////////////////////////////Microwire////////////////////////////////////////////
void mw93xx_menu(void)
{
	TFT_fillScreen(COLOR_BLACK);
	mw93xx_change();
	TFT_drawString(15, 1, "93XX: change operation", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "Device: ", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(58, 16, mw_devs, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Read", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 64, "Erase", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 80, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 8)
	{
		cursor_move(5);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Change chip
				{
					mw_dev++;
					if(mw_dev > 5) mw_dev = 0;
					mw93xx_change();
					TFT_drawString(10, 16, "Device: ", COLOR_GREEN, COLOR_BLACK, 1);
					TFT_drawString(58, 16, mw_devs, COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //Read
				{
					punkt = 0;
					menu = 9;
					break;
				}
				case 2: //Write
				{
					punkt = 0;
					menu = 10;
					break;
				}
				case 3: //Erase
				{
					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "Erasing...", COLOR_GREEN, COLOR_BLACK, 1);
					mw_emptyCmd(mw_addsize, MW_WEN);
					mw_emptyCmd(mw_addsize, MW_ERAL);
					HAL_Delay(200);
					while(mw_waitBsy());
					mw_emptyCmd(mw_addsize, MW_WDIS);
					clear_consoleRow();
					TFT_drawString(8, _maxY - 8, "Chip erased", COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 4: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 0;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

void mw93xx_readMenu(void)
{
	uint8_t nam_str[] = "mw93fil0.bin";
	uint16_t data;
	//Progress bar
	uint32_t one_del,del_count;

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "93XX: read settings", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File name:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(80, 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Start", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	while(menu == 9)
	{
		cursor_move(3);
		if(set)
		{

			switch(punkt)
			{
				case 0: //F_Name
				{
					punkt1++;
					if(punkt1 >= 8)punkt1 = 0;
					TFT_fillRectangle(80, 24, _maxX - 80, 8, COLOR_BLACK);
					TFT_drawChar(80+(punkt1*6), 24, '^', COLOR_GREEN, COLOR_BLACK, 1);
					break;
				}
				case 1: //Start
				{
					Fr = f_open(&Fil, nam_str, FA_CREATE_ALWAYS | FA_WRITE);

					if(Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "SD not mounted", COLOR_GREEN, COLOR_BLACK, 1);
						break;
					}
					else
					{
						//Progress bar
						one_del = f_size/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						for(uint32_t i = 0; i < f_size; i += 128)
						{
							for(int j = 0; j < 64; j++)
							{
								data = mw_readCmd(mw_addsize, j + i / 2);
								main_buff[j * 2] = data & 0xFF;
								main_buff[(j * 2) + 1] = (data >> 8) & 0xFF;
							}

							Fr = f_write(&Fil, main_buff, 128, &writed);
							if(Fr != FR_OK)
							{
								clear_consoleRow();
								sprintf(string, "SD write error: %d", Fr);
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							else //Draw progress bar result
							{
								del_count = i/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
						f_close(&Fil);
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_BLACK);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 8;
					break;
				}
			}
			set = 0;
		}
		if(left)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] > 0x30) nam_str[punkt1]--;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			left = 0;
		}
		if(right)
		{
			if(punkt==0)
			{
				if(nam_str[punkt1] < 0x7F) nam_str[punkt1]++;
				TFT_drawString(80, 16, nam_str, COLOR_GREEN, COLOR_BLACK, 1);
			}
			right = 0;
		}
	}
}

void mw93xx_writeMenu(void)
{
	uint8_t fil_changed = 0;
	uint8_t tmp_buff[32];

	TFT_fillScreen(COLOR_BLACK);
	TFT_drawString(15, 1, "93XX: write file", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 16, "File:", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 32, "Write", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawString(10, 48, "Return", COLOR_GREEN, COLOR_BLACK, 1);
	TFT_drawChar(0, 16, '>', COLOR_GREEN, COLOR_BLACK, 1);
	punkt = 0;

	Fres = f_opendir(&dir, ""); //Пытаемся открыть root dir
	if(Fres != FR_OK) TFT_drawString(8, _maxY - 8, "SD Card not mounted", COLOR_GREEN, COLOR_BLACK, 1);
	else
	{
		Fr = f_readdir(&dir, &fno);
		if (Fr != FR_OK || fno.fname[0] == 0)
		{
			clear_consoleRow();
			TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
		}
		else
		{
			if(fno.fattrib & AM_DIR)
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
				TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 0;
			}
			else
			{
				TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
				TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
				TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
				fil_changed = 1;
			}
		}
	}

	while(menu == 10)
	{
		cursor_move(3);
		if(set)
		{
			switch(punkt)
			{
				case 0: //Change file
				{
					Fr = f_readdir(&dir, &fno);
					if (Fr != FR_OK)
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No files in root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else if(fno.fname[0] == 0 || fno.fname[0] == '.')
					{
						f_closedir(&dir);
						f_opendir(&dir, "");
						TFT_fillRectangle(88, 16, _maxX - 88, 8, COLOR_BLACK);
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "End of root", COLOR_GREEN, COLOR_BLACK, 1);
					}
					else
					{
						clear_consoleRow();
						if(fno.fattrib & AM_DIR)
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, "DIR\\", COLOR_GREEN, COLOR_BLACK, 1);
							TFT_drawString(70, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 0;
						}
						else
						{
							TFT_fillRectangle(46, 16, _maxX - 46, 8, COLOR_BLACK);
							TFT_fillRectangle(0, 24, _maxX, 8, COLOR_BLACK);
							TFT_drawString(46, 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
							fil_changed = 1;
						}
					}

					break;
				}
				case 1: //Write
				{
					if(fil_changed)
					{
						uint32_t offset = 0;
						//Progress bar
						uint32_t one_del, del_count;

						Fr = f_open(&Fil, fno.fname, FA_READ);
						if(Fr != FR_OK)
						{
							clear_consoleRow();
							TFT_drawString(8, _maxY - 8, "File open error", COLOR_GREEN, COLOR_BLACK, 1);
							break;
						}

						one_del = fno.fsize/PB_RESOLUTION;
						TFT_fillRectangle(38, _maxY - 8, 100, 4, COLOR_WHITE);

						mw_emptyCmd(mw_addsize, MW_WEN);

						while(1)
						{
							Fr = f_read(&Fil, main_buff, 128, &readed);
							if(Fr != FR_OK)
							{
								sprintf(string, "File read error: %d", Fr);
								clear_consoleRow();
								TFT_drawString(8, _maxY - 8, string, COLOR_GREEN, COLOR_BLACK, 1);
								TFT_fillRectangle(0, _maxY - 16, _maxX, 8, COLOR_BLACK);
								TFT_drawString(8, _maxY - 16, fno.fname, COLOR_GREEN, COLOR_BLACK, 1);
								break;
							}
							if(readed == 0)//Выходим из цикла
							{
								mw_emptyCmd(mw_addsize, MW_WDIS);
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							if(readed < 128) for(int i = 0; i < (128 - readed); i++) main_buff[i+readed] = 0xFF;
							//Writing
							for(int i = 0; i < 64; i++)
							{
								mw_writeCmd(mw_addsize, offset/2+i, (main_buff[2*i]|(main_buff[2*i+1]<<8)));
								while(mw_waitBsy());
								HAL_Delay(15);
							}

							offset += 128;

							if(readed < 128)//Выходим из цикла
							{
								mw_emptyCmd(mw_addsize, MW_WDIS);
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLACK);
								break;
							}
							else //Рисуем progress bar
							{
								del_count = offset/one_del;
								TFT_fillRectangle(38, _maxY - 8, del_count, 4, COLOR_BLUE);
							}
						}
					}
					else
					{
						clear_consoleRow();
						TFT_drawString(8, _maxY - 8, "No changed file", COLOR_GREEN, COLOR_BLACK, 1);
					}
					break;
				}
				case 2: //Return
				{
					punkt = 0;
					punkt1 = 0;
					menu = 8;
					break;
				}
			}
			set = 0;
		}
		if(left) left = 0;
		if(right) right = 0;
	}
}

void mw93xx_change(void)
{
	switch(mw_dev)
	{
		case 0: {mw_addsize = 6; f_size = 128; mw_devs = "93C46"; break;}
		case 1: {mw_addsize = 7; f_size = 256; mw_devs = "93C56"; break;}
		case 2: {mw_addsize = 8; f_size = 256; mw_devs = "93C57"; break;}
		case 3: {mw_addsize = 8; f_size = 512; mw_devs = "93C66"; break;}
		case 4: {mw_addsize = 10; f_size = 1024; mw_devs = "93C76"; break;}
		case 5: {mw_addsize = 10; f_size = 2048; mw_devs = "93C86"; break;}
	}
}
