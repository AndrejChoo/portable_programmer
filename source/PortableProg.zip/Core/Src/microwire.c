/*
 * microwire.c
 *
 *  Created on: Jan 28, 2025
 *      Author: andre
 */

#include "microwire.h"

#define mw_freq			10

void _delay_us(uint16_t dl)
{
	TIM3->ARR = dl;                  //загрузить значение задержки
	TIM3->CNT = 0;
	TIM3->CR1 = TIM_CR1_CEN;	          //запустить таймер
	while((TIM3->SR & TIM_SR_UIF)==0); //дождаться конца задержки
	TIM3->SR &= ~TIM_SR_UIF;	          //сбросить флаг
}

uint16_t mw_readCmd(uint16_t width, uint32_t add)
{
	uint32_t tadd, tdat = 0;
	tadd = (6 << (width + 1)) | (add << 1);

	MWCS_HIGH
	_delay_us(mw_freq);

	//Отправляем комманду чтения + адресс + бит ожидания
	for(uint32_t i = 0; i < (width + 4); i++)
	{
		if(tadd & (1 << (width + 3 - i))) PGDO_HIGH
		else PGDO_LOW
		_delay_us(mw_freq);
		PGC_HIGH
		_delay_us(mw_freq);
		PGC_LOW
	}

	//Читаем 16 битное слово
	for(uint32_t i = 0; i < 16; i++)
	{
		_delay_us(mw_freq);
		//заполняем данные побитно
		if(PGD_READ) tdat |= (1 << (15 - i));
		PGC_HIGH
		_delay_us(mw_freq);
		PGC_LOW
	}
	_delay_us(mw_freq);
	MWCS_LOW
	PGDO_LOW
	PGC_LOW

	return tdat;
}

void mw_writeCmd(uint8_t width, uint32_t add, uint16_t dat)
{
	uint32_t tadd;
	tadd = add | (0x05 << width);

	MWCS_HIGH
	_delay_us(mw_freq);

	//Отправляем комманду записи + адресс + бит ожидания
	for(uint32_t i = 0; i < (width + 3); i++)
	{
		if(tadd & (1 << (width + 2 - i))) PGDO_HIGH
		else PGDO_LOW
		_delay_us(mw_freq);
		PGC_HIGH
		_delay_us(mw_freq);
		PGC_LOW
	}
	//Отправляем данные на запись побитно
	for(uint32_t i = 0; i < 16; i++)
	{
		if(dat & (1 << (15 - i))) PGDO_HIGH
		else PGDO_LOW
		_delay_us(mw_freq);
		PGC_HIGH
		//заполняем данные побитно
		_delay_us(mw_freq);
		PGC_LOW
	}
	_delay_us(mw_freq);
	MWCS_LOW
	PGDO_LOW
	PGC_LOW

	_delay_us(100);
}

void mw_emptyCmd(uint8_t width, uint8_t cmd)
{
	uint16_t tadd;
	tadd = cmd << (width - 2);

	MWCS_HIGH
	_delay_us(mw_freq);

	//Отправляем комманду чтения + адресс + бит ожидания
	for(int i = 0; i < (width + 3); i++)
	{
		if(tadd & (1 << (width + 2 - i))) PGDO_HIGH
		else PGDO_LOW
		_delay_us(mw_freq);
		PGC_HIGH
		_delay_us(mw_freq);
		PGC_LOW
	}

	MWCS_LOW
	PGDO_LOW
	PGC_LOW

	_delay_us(100);
}

uint8_t mw_waitBsy(void)
{
	MWCS_HIGH
	_delay_us(400);
	if(!PGD_READ)
	{
		_delay_us(50);
		MWCS_LOW
		return 1;
	}
	MWCS_LOW
	return 0;
}

