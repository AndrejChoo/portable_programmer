/*
 * microwire.h
 *
 *  Created on: Jan 28, 2025
 *      Author: andre
 */

#ifndef INC_MICROWIRE_H_
#define INC_MICROWIRE_H_

#include "main.h"


#define MW_WEN		0x13
#define MW_WDIS		0x10
#define MW_ERAL		0x12

#define PGD_READ			(PGDI_PORT->IDR & PGDI_PIN)

#define PGDI_PORT			GPIOB
#define PGDO_PORT			GPIOB
#define PGC_PORT			GPIOB
#define MWCS_PORT			GPIOA
#define MWCS_PIN			GPIO_PIN_2
#define PGDI_PIN			GPIO_PIN_1
#define PGDO_PIN			GPIO_PIN_0
#define PGC_PIN				GPIO_PIN_2

#define     PGDO_HIGH      	HAL_GPIO_WritePin(PGDO_PORT, PGDO_PIN, GPIO_PIN_SET);
#define     PGDO_LOW       	HAL_GPIO_WritePin(PGDO_PORT, PGDO_PIN, GPIO_PIN_RESET);
#define     PGC_HIGH      	HAL_GPIO_WritePin(PGC_PORT, PGC_PIN, GPIO_PIN_SET);
#define     PGC_LOW       	HAL_GPIO_WritePin(PGC_PORT, PGC_PIN, GPIO_PIN_RESET);
#define     MWCS_HIGH      	HAL_GPIO_WritePin(MWCS_PORT, MWCS_PIN, GPIO_PIN_SET);
#define     MWCS_LOW       	HAL_GPIO_WritePin(MWCS_PORT, MWCS_PIN, GPIO_PIN_RESET);


void _delay_us(uint16_t dl);
uint16_t mw_readCmd(uint16_t width, uint32_t add);
void mw_writeCmd(uint8_t width, uint32_t add, uint16_t dat);
void mw_emptyCmd(uint8_t width, uint8_t cmd);
uint8_t mw_waitBsy(void);

#endif /* INC_MICROWIRE_H_ */
