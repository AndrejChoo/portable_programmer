/*
 * avr.h
 *
 *  Created on: Jan 31, 2025
 *      Author: andre
 */

#ifndef INC_AVR_H_
#define INC_AVR_H_

#include "main.h"
#include "microwire.h"
#include "screen.h"
#include "avr_devs.h"

//MISO - PB1, MOSI - PB0, SCK - PB2, RST - PB12
#define AVRCS_HIGH		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
#define AVRCS_LOW		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);

uint8_t sspi_transfer(uint8_t dat);
uint8_t avr_progMode(void);
uint8_t avr_enterProg(void);
uint8_t avr_sendCmd(uint8_t comm, uint16_t arg, uint8_t dat);
uint8_t avr_checkBusy(void);
uint8_t avr_readFuses(void);
void clear_fusePointers(void);
void draw_avrModel(uint16_t dev);

void avr_menu(void);
void avr_fuseMenu(void);
void avr_settingsMenu(void);
void avr_readFlMenu(void);
void avr_readEeMenu(void);
void avr_writeFlMenu(void);
void avr_writeEeMenu(void);

#endif /* INC_AVR_H_ */
