/*
 * game.h
 *
 *  Created on: Jan 27, 2025
 *      Author: andre
 */

#ifndef INC_GAME_H_
#define INC_GAME_H_

#include "main.h"
#include "ili9225.h"
#include "screen.h"

#define bool	uint8_t

void game_menu(void);

void tetris(void);
void game_begin(void); //Отрисовывает игровое поле
void game_over(void);
void draw_block(uint16_t x, uint16_t y, bool visible); //Рисует один блок
void draw_fig(uint8_t fig, uint16_t x, uint16_t y, bool visible); //Рисует фигуру
void shift_left(void);
void shift_right(void);
void rotate(void);
void delay(uint16_t);
void check_strings(void);
bool check_pos(uint8_t, uint8_t,uint8_t);
bool check_full(void);
void save_pos(void);
void draw_row(uint8_t, uint16_t);

#endif /* INC_GAME_H_ */
