/*
 * screen.h
 *
 *  Created on: Jan 20, 2025
 *      Author: andre
 */

#ifndef INC_SCREEN_H_
#define INC_SCREEN_H_

#include "ili9225.h"
#include "main.h"
#include "fatfs.h"
#include "progger.h"
#include "microwire.h"
#include <stdio.h>

//
uint16_t hex_toStr(uint8_t h);
//
void clear_changeColumn(void);
void clear_consoleRow(void);
void cursor_move(uint8_t punkt_cnt);

//
void start_screen(void);
void device_menu(void);

//25xx
void fl25xx_menu(void);
void fl25xx_readMenu(void);
void fl25xx_writeSregMenu(void);
void fl25xx_writeMenu(void);

void draw_25xxId(void);
void draw_25xxSreg(void);
void dwaw_25xxSreg1(uint8_t s1, uint8_t s2);

//24xx
void ee24xx_menu(void);
void ee24xx_readMenu(void);
void ee24xx_writeMenu(void);

//93xx
void mw93xx_menu(void);
void mw93xx_readMenu(void);
void mw93xx_writeMenu(void);
void mw93xx_change(void);

#endif /* INC_SCREEN_H_ */
