/*
 * pogger.h
 *
 *  Created on: Jan 21, 2025
 *      Author: andre
 */

#ifndef INC_PROGGER_H_
#define INC_PROGGER_H_

#include "main.h"
#include "spi.h"
#include "i2c.h"

//Int Flash PA4, EXT CS PB0
#define F25CS_HIGH		{while(SPI4->SR & SPI_SR_BSY); HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);}
#define F25CS_LOW		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);


//SPI transfer byte
uint8_t spi_transfer(uint8_t dat);

//SPI FLash 25XX
uint8_t fl25xx_readReg(uint8_t reg);
void fl25xx_getId(uint8_t *dat);
void fl25xx_erase(void);


#endif /* INC_PROGGER_H_ */
